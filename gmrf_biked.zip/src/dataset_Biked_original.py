import os
from PIL import Image
from PIL import ImageChops
import matplotlib.pyplot as plt
import torch
from torch.utils.data import Dataset, random_split
import random
from torchvision.transforms import functional as F

class BIKED_Dataset(Dataset):
    def __init__(self, root_dir ='../biked_data/BIKED Dataset/BIKED Dataset/Segmented bike images',  component_dirs=None, transform=None):
        """
        Args:
            root_dir (str): Path to the root directory containing subfolders for components.
            component_dirs (list, optional): List of component subfolders to include (e.g., ['crank', 'frame', 'handle', 'saddle', 'wheel']).
            transform (callable, optional): Optional transform to be applied on each image.
        """
        self.root_dir = root_dir
        self.component_dirs = component_dirs or ['crank', 'frame', 'handle', 'saddle', 'wheel']
        self.transform = transform

        # List components and filter out unwanted directories
        self.image_dict = {component: [] for component in self.component_dirs}

        for component_dir in self.component_dirs:
            component_path = os.path.join(self.root_dir, component_dir)
            if not os.path.isdir(component_path):
                continue

            for filename in sorted(os.listdir(component_path)):
                if os.path.isfile(os.path.join(component_path, filename)) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')) and 'bike (607)' not in filename:
                    self.image_dict[component_dir].append(filename)

        # Match files across components by name
        common_filenames = set.intersection(*[set(self.image_dict[component]) for component in self.component_dirs])
        self.matched_files = {filename: {component: os.path.join(self.root_dir, component, filename) for component in self.component_dirs} for filename in common_filenames}

    def __len__(self):
        return len(self.matched_files)

    def __getitem__(self, idx):
        # Get the filename for the current index
        filename = list(self.matched_files.keys())[idx]

        # Load and transform images for each component
        images = {}
        for component, filepath in self.matched_files[filename].items():
            image = Image.open(filepath).convert("RGB")  # Load as RGB
            if self.transform:
                image = self.transform(image)
            images[component] = image

        return images

    def get_unique_resolutions(self):
        """
        Returns a dictionary with the unique resolutions of each component.

        Returns:
            dict: A dictionary where keys are component names and values are sets of unique resolutions.
        """
        resolutions = {component: set() for component in self.component_dirs}

        for filename in self.matched_files:
            for component, filepath in self.matched_files[filename].items():
                image = Image.open(filepath)
                resolutions[component].add(image.size)

        return resolutions
    
    def reduce_resolution(self, target_resolution=(64, 64), apply_transformations=False):
        """
        Creates a new data folder with reduced resolution images and optionally applies transformations.

        Args:
            target_resolution (tuple): Target resolution (width, height) for the images.
            apply_transformations (bool): Whether to apply transformations (resize, grayscale, invert).
        """
        # Create a new parent folder name with resolution info
        new_root_dir = f"{self.root_dir}_res{target_resolution[0]}x{target_resolution[1]}"
        if os.path.exists(new_root_dir):
            print(f"Folder {new_root_dir} already exists. Skipping resolution reduction.")
            return

        os.makedirs(new_root_dir, exist_ok=True)

        for component in self.component_dirs:
            # Create component subfolder in the new root directory
            new_component_path = os.path.join(new_root_dir, component)
            os.makedirs(new_component_path, exist_ok=True)

            for filename in self.image_dict[component]:
                old_filepath = os.path.join(self.root_dir, component, filename)
                new_filepath = os.path.join(new_component_path, filename)

                # Open the image
                image = Image.open(old_filepath)

                if apply_transformations:
                    # Resize and convert to grayscale
                    image = F.resize(image, target_resolution)
                    image = F.rgb_to_grayscale(image, num_output_channels=1)

                    # Convert to a tensor, normalize, and invert pixel values
                    tensor = F.to_tensor(image)  # Scales to [0, 1]
                    tensor = 1 - tensor  # Invert pixel values
                    image = F.to_pil_image(tensor)  # Convert back to PIL image for saving
                else:
                    # Only resize the image (no grayscale, no inversion)
                    image = image.resize(target_resolution, Image.ANTIALIAS)

                # Save the processed image
                image.save(new_filepath)

        print(f"Processed images saved in: {new_root_dir}")
    

    def superpose_components(self, components_dict, output_dir=None, grayscale=False):
        """
        Superposes the given components (images) and either saves or plots the resulting image.

        Args:
            components_dict (dict): A dictionary with component names as keys and PIL Image objects as values.
            output_dir (str, optional): Directory to save the superposed image. If None, the image will be plotted.
            grayscale (bool): If True, assumes grayscale images and makes black pixels transparent while coloring components.
        """
        superposed_image = None
        component_colors = {
            'crank': (255, 0, 0, 128),  # Red
            'frame': (0, 255, 0, 128),  # Green
            'handle': (0, 0, 255, 128),  # Blue
            'saddle': (255, 255, 0, 128),  # Yellow
            'wheel': (255, 0, 255, 128)  # Magenta
        }

        for component, image in components_dict.items():
            if grayscale:
                image = image.convert("L").convert("RGBA")  # Ensure grayscale converted to RGBA
                datas = image.getdata()
                new_data = []
                for item in datas:
                    if item[0] == 0:  # Check for black pixel
                        new_data.append((0, 0, 0, 0))  # Make transparent
                    else:
                        # Apply the color based on the component
                        new_data.append(component_colors.get(component, (255, 255, 255, 128)))
                image.putdata(new_data)

            else:
                image = image.convert("RGBA")
                datas = image.getdata()
                new_data = []
                for item in datas:
                    if item[:3] == (255, 255, 255):  # White pixel
                        new_data.append((255, 255, 255, 0))  # Transparent
                    else:
                        new_data.append(item)
                image.putdata(new_data)

            if superposed_image is None:
                superposed_image = Image.new("RGBA", image.size, (255, 255, 255, 0))
            superposed_image = Image.alpha_composite(superposed_image, image)

        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
            filename = "superposed_bike.png"
            output_filepath = os.path.join(output_dir, filename)
            superposed_image.convert("RGB").save(output_filepath)
            print(f"Superposed image saved at: {output_filepath}")
        else:
            # Plot the image if no output directory is provided
            plt.figure(figsize=(8, 8))
            plt.imshow(superposed_image)
            plt.axis('off')
            plt.show()
            
    def split_data(self, test_size=0.1, seed=42):
        """
        Split the dataset into training and testing sets.

        Args:
            test_size (float): The proportion of the dataset to include in the test split.
            seed (int, optional): Random seed for reproducibility. Default is 42.

        Returns:
            train_dataset (Dataset): The training dataset.
            test_dataset (Dataset): The test dataset.
        """
        # Shuffle the data indices
        total_size = len(self)
        indices = list(range(total_size))
        if seed is not None:
            random.seed(seed)
        random.shuffle(indices)

        # Calculate the size of the test set
        test_size = int(total_size * test_size)
        train_size = total_size - test_size

        # Split the indices into train and test
        train_indices, test_indices = indices[:train_size], indices[train_size:]

        # Create subsets for training and testing
        train_dataset = torch.utils.data.Subset(self, train_indices)
        test_dataset = torch.utils.data.Subset(self, test_indices)

        return train_dataset, test_dataset






# import os
# from PIL import Image
# import torch
# from torch.utils.data import Dataset, random_split
# import random

# class BIKED_Dataset(Dataset):
#     def __init__(self, root_dir ='../biked_data/BIKED Dataset/BIKED Dataset/Segmented bike images', 
#                  component_dirs=None, transform=None):
#         """
#         Args:
#             root_dir (str): Path to the root directory containing subfolders for components.
#             component_dirs (list, optional): List of component subfolders to include (e.g., ['crank', 'frame', 'handle', 'saddle', 'wheel']).
#             transform (callable, optional): Optional transform to be applied on each image.
#         """
#         self.root_dir = root_dir
#         self.component_dirs = component_dirs or ['crank', 'frame', 'handle', 'saddle', 'wheel']
#         self.transform = transform

#         # List components and filter out unwanted directories
#         self.image_dict = {component: [] for component in self.component_dirs}

#         for component_dir in self.component_dirs:
#             component_path = os.path.join(self.root_dir, component_dir)
#             if not os.path.isdir(component_path):
#                 continue

#             for filename in sorted(os.listdir(component_path)):
#                 if os.path.isfile(os.path.join(component_path, filename)) and filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')) and 'bike (607)' not in filename:
#                     self.image_dict[component_dir].append(filename)

#         # Match files across components by name
#         common_filenames = set.intersection(*[set(self.image_dict[component]) for component in self.component_dirs])
#         self.matched_files = {filename: {component: os.path.join(self.root_dir, component, filename) for component in self.component_dirs} for filename in common_filenames}

#     def __len__(self):
#         return len(self.matched_files)

#     def __getitem__(self, idx):
#         # Get the filename for the current index
#         filename = list(self.matched_files.keys())[idx]

#         # Load and transform images for each component
#         images = {}
#         for component, filepath in self.matched_files[filename].items():
#             image = Image.open(filepath).convert("RGB")  # Load as RGB
#             if self.transform:
#                 image = self.transform(image)
#             images[component] = image

#         return images

#     def split_data(self, test_size=0.1, seed=42):
#         """
#         Split the dataset into training and testing sets.

#         Args:
#             test_size (float): The proportion of the dataset to include in the test split.
#             seed (int, optional): Random seed for reproducibility. Default is 42.

#         Returns:
#             train_dataset (Dataset): The training dataset.
#             test_dataset (Dataset): The test dataset.
#         """
#         # Shuffle the data indices
#         total_size = len(self)
#         indices = list(range(total_size))
#         if seed is not None:
#             random.seed(seed)
#         random.shuffle(indices)

#         # Calculate the size of the test set
#         test_size = int(total_size * test_size)
#         train_size = total_size - test_size

#         # Split the indices into train and test
#         train_indices, test_indices = indices[:train_size], indices[train_size:]

#         # Create subsets for training and testing
#         train_dataset = torch.utils.data.Subset(self, train_indices)
#         test_dataset = torch.utils.data.Subset(self, test_indices)

#         return train_dataset, test_dataset
