# objectives of choice
import torch
import torch.nn as nn
from numpy import prod
from utils import log_mean_exp, is_multidata


# helper to vectorise computation
def compute_microbatch_split(x, K):
    """ Checks if batch needs to be broken down further to fit in memory. """
    B = x[0].size(0) if is_multidata(x) else x.size(0)
    S = sum([1.0 / (K * prod(_x.size()[1:])) for _x in x]) if is_multidata(x) \
        else 1.0 / (K * prod(x.size()[1:]))
    S = int(1e8 * S)  # float heuristic for 12Gb cuda memory
    assert (S > 0), "Cannot fit individual data in memory, consider smaller K"
    return min(B, S)

def _m_iwae(model, x, K=1, test=False):
    """IWAE estimate for log p_\theta(x) for multi-modal vae -- fully vectorised
    This version is the looser bound---with the average over modalities outside the log
    """
    if test:
        qu_xs, px_us, uss = model.reconstruct_and_cross_reconstruct_forw(x)
    else:
        qu_xs, px_us, uss = model(x, K)
    qz_xs, qw_xs = [], []
    for r, qu_x in enumerate(qu_xs):
        qu_x_r_mean, qu_x_r_lv = model.vaes[r].qu_x_params
        qw_x_mean, qz_x_mean = torch.split(qu_x_r_mean, [model.params.latent_dim_w, model.params.latent_dim_z], dim=-1)
        qw_x_lv, qz_x_lv = torch.split(qu_x_r_lv, [model.params.latent_dim_w, model.params.latent_dim_z], dim=-1)
        qw_x = model.vaes[r].qu_x(qw_x_mean, qw_x_lv)
        qz_x = model.vaes[r].qu_x(qz_x_mean, qz_x_lv)
        qz_xs.append(qz_x)
        qw_xs.append(qw_x)
    lws = []
    for r, qu_x in enumerate(qu_xs):
        lpu = model.pu(*model.pu_params).log_prob(uss[r]).sum(-1)
        ws, zs = torch.split(uss[r], [model.params.latent_dim_w, model.params.latent_dim_z], dim=-1)
        lqz_x = log_mean_exp(torch.stack([qz_x.log_prob(zs).sum(-1) for qz_x in qz_xs]))
        lqw_x = qw_xs[r].log_prob(ws).sum(-1)
        lpx_u = [px_u.log_prob(x[d]).view(*px_u.batch_shape[:2], -1)
                     .mul(model.vaes[d].llik_scaling).sum(-1)
                 for d, px_u in enumerate(px_us[r])]
        lpx_u = torch.stack(lpx_u).sum(0)
        lw = lpx_u + model.params.beta*(lpu - lqz_x - lqw_x)
        lws.append(lw)
    return torch.stack(lws)  # (n_modality * n_samples) x batch_size, batch_size

def m_elbo(model, x, K=1, test=False):
    """Computes iwae estimate for log p_\theta(x) for multi-modal vae
    This version is the looser bound---with the average over modalities outside the log
    """
    S = compute_microbatch_split(x, K)
    x_split = zip(*[_x.split(S) for _x in x])
    lw = [_m_iwae(model, _x, K, test=test) for _x in x_split]
    lw = torch.cat(lw, 2)  # concat on batch
    return log_mean_exp(lw, dim=1).mean(0).sum()


def _m_dreg(model, x, K=1, test=False):
    """DReG estimate for log p_\theta(x) for multi-modal vae -- fully vectorised
    This version is the looser bound---with the average over modalities outside the log
    """
    if test:
        qu_xs, px_us, uss = model.reconstruct_and_cross_reconstruct_forw(x)
    else:
        qu_xs, px_us, uss = model(x, K)
    qu_xs_ = [vae.qu_x(*[p.detach() for p in vae.qu_x_params]) for vae in model.vaes]
    qz_xs, qw_xs = [], []
    for r, qu_x in enumerate(qu_xs_):
        qu_x_r_mean, qu_x_r_lv = model.vaes[r].qu_x_params
        qw_x_mean, qz_x_mean = torch.split(qu_x_r_mean, [model.params.latent_dim_w, model.params.latent_dim_z], dim=-1)
        qw_x_lv, qz_x_lv = torch.split(qu_x_r_lv, [model.params.latent_dim_w, model.params.latent_dim_z], dim=-1)
        qw_x = model.vaes[r].qu_x(qw_x_mean, qw_x_lv)
        qz_x = model.vaes[r].qu_x(qz_x_mean, qz_x_lv)
        qz_xs.append(qz_x)
        qw_xs.append(qw_x)
    lws = []
    for r, qu_x in enumerate(qu_xs_):
        lpu = model.pu(*model.pu_params).log_prob(uss[r]).sum(-1)
        ws, zs = torch.split(uss[r], [model.params.latent_dim_w, model.params.latent_dim_z], dim=-1)
        lqz_x = log_mean_exp(torch.stack([qz_x.log_prob(zs).sum(-1) for qz_x in qz_xs]))
        lqw_x = qw_xs[r].log_prob(ws).sum(-1)
        lpx_u = [px_u.log_prob(x[d]).view(*px_u.batch_shape[:2], -1)
                     .mul(model.vaes[d].llik_scaling).sum(-1)
                 for d, px_u in enumerate(px_us[r])]
        lpx_u = torch.stack(lpx_u).sum(0)
        lw = lpx_u + model.params.beta*(lpu - lqz_x - lqw_x)
        lws.append(lw)
    return torch.stack(lws), torch.stack(uss)

def m_dreg(model, x, K=1, test=False):
    """Computes DReG estimate for log p_\theta(x) for multi-modal vae
    This version is the looser bound---with the average over modalities outside the log
    """
    S = compute_microbatch_split(x, K)
    x_split = zip(*[_x.split(S) for _x in x])
    lw, uss = zip(*[_m_dreg(model, _x, K, test=test) for _x in x_split])
    lw = torch.cat(lw, 2)  # concat on batch
    uss = torch.cat(uss, 2)  # concat on batch
    with torch.no_grad():
        grad_wt = (lw - torch.logsumexp(lw, 1, keepdim=True)).exp()
        if uss.requires_grad:
            uss.register_hook(lambda grad: grad_wt.unsqueeze(-1) * grad)
    return (grad_wt * lw).mean(0).sum()

def kl_divergence_gaussians(mu_q, Sigma_q, mu_p, Sigma_p):
    """
    Compute the KL divergence between two multivariate Gaussians.

    Args:
        mu_q: Mean of q(z|x), shape [batch_size, latent_dim]
        Sigma_q: Covariance matrix of q(z|x), shape [batch_size, latent_dim, latent_dim]
        mu_p: Mean of p(z), shape [latent_dim]
        Sigma_p: Covariance matrix of p(z), shape [latent_dim, latent_dim]

    Returns:
        kl_div: KL divergence, scalar
    """
    batch_size, latent_dim = mu_q.shape

    # Inverse of Sigma_p: [latent_dim, latent_dim]
    Sigma_p_inv = torch.inverse(Sigma_p)

    # Expand Sigma_p and Sigma_p_inv to match the batch size
    Sigma_p_expanded = Sigma_p.unsqueeze(0).expand(batch_size, latent_dim, latent_dim)  # [batch_size, latent_dim, latent_dim]
    Sigma_p_inv_expanded = Sigma_p_inv.unsqueeze(0).expand(batch_size, latent_dim, latent_dim)  # [batch_size, latent_dim, latent_dim]

    # Compute trace term: trace(Sigma_p_inv @ Sigma_q)
    trace_term = torch.einsum('bij,bij->b', Sigma_p_inv_expanded, Sigma_q)  # [batch_size]

    # Compute difference of means
    diff = mu_q - mu_p.unsqueeze(0)  # [batch_size, latent_dim]

    # Mahalanobis term: (mu_p - mu_q)^T @ Sigma_p_inv @ (mu_p - mu_q)
    mahalanobis_term = torch.einsum('bi,bij,bj->b', diff, Sigma_p_inv_expanded, diff)  # [batch_size]

    # Compute log determinant terms using torch.slogdet
    # For Sigma_q: batch of matrices
    sign_q, logdet_q = torch.slogdet(Sigma_q)  # Both [batch_size]
    # For Sigma_p: single matrix
    sign_p, logdet_p = torch.slogdet(Sigma_p)  # Scalars

    # Check that determinants are positive
    if not torch.all(sign_q > 0):
        raise ValueError("Sigma_q is not positive definite")
    if sign_p <= 0:
        raise ValueError("Sigma_p is not positive definite")

    # Compute KL divergence for each sample in the batch
    kl_div = 0.5 * (logdet_p - logdet_q - latent_dim + trace_term + mahalanobis_term)  # [batch_size]

    return kl_div.mean()
# (model, data, beta,l1=l1, custom= custom)
# def compute_elbo_dist(model, data, beta=1, l1=False):
#     """
#     Compute the ELBO loss (without importance sampling).

#     Args:
#         model: The VAE model.
#         data: Tuple containing image data and text data.
#         alpha: Weight for image reconstruction term.
#         beta: Weight for KL divergence term.
#         laplace: Whether to use Laplace distribution for image reconstruction.
#         verbose: Whether to print debug information.
#         scale: Scale parameter for the distributions (default 0.01).

#     Returns:
#         loss: The ELBO loss to minimize.
#         image_recon_term: Image reconstruction loss (for reporting).
#         crossentropy_term: Text reconstruction loss (for reporting).
#         kl_divergence: KL divergence (for reporting).
#     """
    
#     mu_p = model.mu_p  # Shape: [total_latent_dim]
#     L_p = model.get_cholesky()  # Shape: [total_latent_dim, total_latent_dim]
#     Sigma_p = torch.matmul(L_p, L_p.transpose(-2, -1))  # [total_latent_dim, total_latent_dim]
    
#     mu_q = model.muq  # Shape: [batch_size, total_latent_dim]
#     Sigma_q = model.Sigmaq
    
    

#     # Compute KL divergence
#     kl_divergence = kl_divergence_gaussians(mu_q, Sigma_q, mu_p, Sigma_p)


#     # Monte Carlo estimate of p(x|z) using L1 Loss instead of MSE
#     if l1:
#         recon_term = sum(nn.L1Loss()(mu, d) for mu, d in zip(model.recons, data))
#     else:
#         recon_term = sum(nn.MSELoss()(mu, d) for mu, d in zip(model.recons, data))
#     elbo = -recon_term - beta*kl_divergence
#     return elbo, -recon_term, kl_divergence
def compute_elbo_dist(model, data, beta=1, l1=False):
    """
    Compute the ELBO loss (without importance sampling).

    Args:
        model: The VAE model.
        data: Tuple containing image data and text data.
        alpha: Weight for image reconstruction term.
        beta: Weight for KL divergence term.
        laplace: Whether to use Laplace distribution for image reconstruction.
        verbose: Whether to print debug information.
        scale: Scale parameter for the distributions (default 0.01).

    Returns:
        loss: The ELBO loss to minimize.
        image_recon_term: Image reconstruction loss (for reporting).
        crossentropy_term: Text reconstruction loss (for reporting).
        kl_divergence: KL divergence (for reporting).
    """
    
    mu_p = model.mu_p  # Shape: [total_latent_dim]
    # L_p = model.get_cholesky()  # Shape: [total_latent_dim, total_latent_dim]
    Sigma_p = model.get_sigma_p()
    # Sigma_p = torch.matmul(L_p, L_p.transpose(-2, -1))  # [total_latent_dim, total_latent_dim]
    
    mu_q = model.muq  # Shape: [batch_size, total_latent_dim]
    Sigma_q = model.Sigmaq
    
    
    # Compute KL divergence
    kl_divergence = kl_divergence_gaussians(mu_q, Sigma_q, mu_p, Sigma_p)


    # Monte Carlo estimate of p(x|z) using L1 Loss instead of MSE
    if l1:
        recon_term = sum(nn.L1Loss()(mu, d) for mu, d in zip(model.recons, data))
    else:
        recon_term = sum(nn.MSELoss()(mu, d) for mu, d in zip(model.recons, data))
    elbo = -recon_term - beta*kl_divergence
    return elbo, -recon_term, kl_divergence

def compute_elbo(model, data, beta=1, l1 = False):
    # Monte Carlo estimate for the KL divergence between q(z|x) and p(z)
    p_z = model.get_prior()
    
    z = model.z_x

    kl_divergence = (model.qz_x.log_prob(z)-p_z.log_prob(z)).mean()
    # Monte Carlo estimate of p(x|z) using L1 Loss instead of MSE
    if l1:
        recon_term = sum(nn.L1Loss()(mu, d) for mu, d in zip(model.recons, data))
    else:
        recon_term = sum(nn.MSELoss()(mu, d) for mu, d in zip(model.recons, data))

    elbo = -recon_term - beta*kl_divergence
    return elbo, -recon_term, kl_divergence


def compute_elbo_mmd(model, data, beta=1, l1 = False, custom = False):
    # Monte Carlo estimate for the KL divergence between q(z|x) and p(z)
    z_q = model.z_x

    z_p =  model.sample_from_pz(z_q.shape[0])

    loss_mmd = compute_mmd(z_q,z_p)#.mean()
    if custom:
        loss_mmd = torch.log(loss_mmd+1)
    loss_mmd = loss_mmd.mean()
    
    if l1:
        recon_term = sum(nn.L1Loss()(mu, d) for mu, d in zip(model.recons, data))
    else:
        recon_term = sum(nn.MSELoss()(mu, d) for mu, d in zip(model.recons, data))

    elbo = -recon_term - beta*loss_mmd

    return elbo, -recon_term, loss_mmd


# https://github.com/pratikm141/MMD-Variational-Autoencoder-Pytorch-InfoVAE/blob/master/mmd_vae_pytorchver.ipynb
"""
Consider trying different Kernels

"""
def compute_kernel(x, y):
    x_size = x.shape[0]
    y_size = y.shape[0]
    dim = x.shape[1]

    tiled_x = x.view(x_size,1,dim).repeat(1, y_size,1)
    tiled_y = y.view(1,y_size,dim).repeat(x_size, 1,1)

    return torch.exp(-torch.mean((tiled_x - tiled_y)**2,dim=2)/dim*1.0)


def compute_mmd(x, y):
    x_kernel = compute_kernel(x, x)
    y_kernel = compute_kernel(y, y)
    xy_kernel = compute_kernel(x, y)
    return torch.mean(x_kernel) + torch.mean(y_kernel) - 2*torch.mean(xy_kernel)


# def compute_elbo(model, data, beta=1):

#     # Monte Carlo estimate for the KL divergence between q(z|x) and p(z)
#     p_z = model.get_prior()
    
#     z = model.z_x

#     kl_divergence = (p_z.log_prob(z)-model.qz_x.log_prob(z)).mean()
#     # Monte Carlo estimate of p(x|z)
#     recon_term = sum(nn.MSELoss()(mu, d) for mu, d in zip(model.recons, data))

#     elbo = -recon_term + beta*kl_divergence
#     return elbo, -recon_term, kl_divergence

# def compute_elbo_dreg(x, qz_x, px_z, z):
#   x = x.view(-1, 784)
#   lpx_z = px_z.log_prob(x).sum(-1)
#   lpz = dist.Normal(torch.zeros_like(z), torch.ones_like(z)).log_prob(z).sum(-1)
#   qz_x_ = qz_x.__class__(qz_x.loc.detach(), qz_x.scale.detach())
#   lqz_x = qz_x_.log_prob(z).sum(-1)

#   lw = lpz + lpx_z - lqz_x
#   with torch.no_grad():
#     reweight = torch.exp(lw - torch.logsumexp(lw, 0))
#     z.register_hook(lambda grad: reweight.unsqueeze(-1) * grad)

#   return (reweight * lw).sum(0).mean(0)

def compute_elbo_dreg(model, data, beta=1):
    z = model.z_x
    lpx_z = sum(vae.px_z.log_prob(d).sum(-1) for vae,d in zip(model.modality_vaes, data))
    pz = model.get_prior()
    lpz = pz.log_prob(z).sum(-1)
    print('lpz shape ', lpz.shape)
    # qz_x_ = model.qz_x.__class__(model.qz_x.loc.detach(), scale_tril = model.qz_x.scale_tril.detach())
    lqz_x = model.qz_x.log_prob(z).sum(-1)
    kl = (lpz - lqz_x)
    print('kl shape ', kl.shape)
    lw = lpx_z +beta*kl
    print('lw shape ', lw.shape)
    with torch.no_grad():
        grad_wt = (lw - torch.logsumexp(lw, 1, keepdim=True)).exp()
        z.register_hook(lambda grad: grad_wt.unsqueeze(-1) * grad)
    elbo = (grad_wt * lw).mean(0).sum()
    print('mean 0 elbo shape ',elbo.shape)
    
    return elbo, lpz, kl





    # with torch.no_grad():
    #     reweight = torch.exp(lw - torch.logsumexp(lw, 0))
    # # Compute the weighted loss for backward
    # weighted_loss = (reweight * lw).mean()
    # print('weighted_loss ', weighted_loss)
    #     # z.register_hook(lambda grad: reweight.unsqueeze(-1) * grad)
    # return elbo, lpz.mean(), kl


def compute_iwae_dreg_multimodal(model, data, z, beta=1, k=5):
    """
    Compute the IWAE with DReG for a model using multimodal data.
    
    Args:
    - model: The VAE model that includes modality_vaes and a method get_prior().
    - data: A list of data batches, where each batch corresponds to a different modality.
    - z: Latent variable samples.
    - beta: Weighting factor for the KL term in the loss.
    - k: The number of importance samples.
    
    Returns:
    - The IWAE loss with DReG, adjusted for multimodal data.
    """
    batch_size = z.size(0)
    
    # Sample z multiple times
    zs = model.reparameterize(z.unsqueeze(1).expand(-1, k, -1).contiguous().view(-1, z.size(-1)))
    
    # Compute log probability of x given z for all modalities
    lpx_z = sum(vae.px_z.log_prob(d.repeat_interleave(k, dim=0)).sum(-1) for vae, d in zip(model.modality_vaes, data))
    
    # Prior and posterior
    pz = model.get_prior()
    lpz = pz.log_prob(zs).view(batch_size, k)
    qz_x_ = model.qz_x.__class__(model.qz_x.loc.detach(), model.qz_x.scale.detach())
    lqz_x = qz_x_.log_prob(zs).view(batch_size, k)
    
    # Compute the KL divergence and reweighted loss
    kl = (lpz - lqz_x).mean(dim=1)
    lw = lpx_z.view(batch_size, k) + beta * kl
    
    with torch.no_grad():
        # Compute log importance weights and normalize them
        log_weights = lw - torch.logsumexp(lw, dim=1, keepdim=True)
        weights = torch.exp(log_weights)
    
    # Importance weighted loss
    loss = torch.logsumexp(lw, dim=1) - torch.log(torch.tensor(k, dtype=torch.float))
    
    # Apply importance weighting for the gradient of q parameters
    for i in range(batch_size):
        z[i].backward(weights[i].unsqueeze(-1) * kl[i].unsqueeze(-1), retain_graph=True)
    
    return -loss.mean()
