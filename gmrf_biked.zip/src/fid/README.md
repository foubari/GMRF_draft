Code is from : https://github.com/mseitzer/pytorch-fid
