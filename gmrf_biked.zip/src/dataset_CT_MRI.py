import os
from PIL import Image
import torch
from torch.utils.data import Dataset, random_split
import random

class CT_MRI_Dataset(Dataset):
    def __init__(self, root_dir='../data/Havard-Medical-Image-Fusion-Datasets-main/CT-MRI', ct_dir='CT', mri_dir='MRI', transform=None):
        """
        Args:
            root_dir (str): Path to the root directory containing CT and MRI folders.
            ct_dir (str): Name of the directory containing CT images.
            mri_dir (str): Name of the directory containing MRI images.
            transform (callable, optional): Optional transform to be applied on each image.
        """
        self.root_dir = root_dir
        self.ct_dir = ct_dir
        self.mri_dir = mri_dir
        self.transform = transform

        # List CT and MRI images
        ct_path = os.path.join(self.root_dir, self.ct_dir)
        mri_path = os.path.join(self.root_dir, self.mri_dir)

        self.ct_images = sorted([f for f in os.listdir(ct_path) if os.path.isfile(os.path.join(ct_path, f)) and f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))])
        self.mri_images = sorted([f for f in os.listdir(mri_path) if os.path.isfile(os.path.join(mri_path, f)) and f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))])

        # Ensure matching file names
        self.matched_files = [(ct_file, mri_file) for ct_file, mri_file in zip(self.ct_images, self.mri_images) if ct_file == mri_file]

    def __len__(self):
        return len(self.matched_files)

    def __getitem__(self, idx):
        # Get the matched file paths for CT and MRI
        ct_file, mri_file = self.matched_files[idx]

        ct_path = os.path.join(self.root_dir, self.ct_dir, ct_file)
        mri_path = os.path.join(self.root_dir, self.mri_dir, mri_file)

        # Load and process images
        ct_image = Image.open(ct_path).convert("L")  # Convert to grayscale
        mri_image = Image.open(mri_path).convert("L")

        if self.transform:
            ct_image = self.transform(ct_image)
            mri_image = self.transform(mri_image)

        return ct_image, mri_image

    def split_data(self, test_size=0.1, seed=42):
        """
        Split the dataset into training and testing sets.

        Args:
            test_size (float): The proportion of the dataset to include in the test split.
            seed (int, optional): Random seed for reproducibility. Default is 42.

        Returns:
            train_dataset (Dataset): The training dataset.
            test_dataset (Dataset): The test dataset.
        """
        # Shuffle the data indices
        total_size = len(self)
        indices = list(range(total_size))
        if seed is not None:
            random.seed(seed)
        random.shuffle(indices)

        # Calculate the size of the test set
        test_size = int(total_size * test_size)
        train_size = total_size - test_size

        # Split the indices into train and test
        train_indices, test_indices = indices[:train_size], indices[train_size:]

        # Create subsets for training and testing
        train_dataset = torch.utils.data.Subset(self, train_indices)
        test_dataset = torch.utils.data.Subset(self, test_indices)

        return train_dataset, test_dataset

    def get_unique_resolutions(self):
        """
        Returns the unique resolutions for CT and MRI images.

        Returns:
            unique_ct_resolutions (set): Unique resolutions for CT images.
            unique_mri_resolutions (set): Unique resolutions for MRI images.
        """
        ct_resolutions = set()
        mri_resolutions = set()

        for ct_file, mri_file in self.matched_files:
            ct_path = os.path.join(self.root_dir, self.ct_dir, ct_file)
            mri_path = os.path.join(self.root_dir, self.mri_dir, mri_file)

            # Open CT and MRI images
            ct_image = Image.open(ct_path)
            mri_image = Image.open(mri_path)

            # Add image sizes to respective sets
            ct_resolutions.add(ct_image.size)  # (width, height)
            mri_resolutions.add(mri_image.size)  # (width, height)

        return ct_resolutions, mri_resolutions