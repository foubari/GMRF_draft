import os
from PIL import Image
from torch.utils.data import Dataset

class BIKED_Dataset(Dataset):
    def __init__(self, root_dir, split="train", component_dirs=None, transform=None):
        """
        Args:
            root_dir (str): Path to the root directory containing 'train' and 'test' subfolders.
            split (str): Which split to use, 'train' or 'test'.
            component_dirs (list, optional): List of component subfolders to include (e.g., ['crank', 'frame', 'handle', 'saddle', 'wheel']).
            transform (callable, optional): Optional transform to be applied on each image.
        """
        self.root_dir = os.path.join(root_dir, split)
        self.component_dirs = component_dirs or ['crank', 'frame', 'handle', 'saddle', 'wheel']
        self.transform = transform

        # List components and filter out unwanted directories
        self.image_dict = {component: [] for component in self.component_dirs}

        for component_dir in self.component_dirs:
            component_path = os.path.join(self.root_dir, component_dir)
            if not os.path.isdir(component_path):
                continue

            for filename in sorted(os.listdir(component_path)):
                if os.path.isfile(os.path.join(component_path, filename)) and filename.lower().endswith((".png", ".jpg", ".jpeg")):
                    self.image_dict[component_dir].append(filename)

        # Match files across components by name
        common_filenames = set.intersection(*[set(self.image_dict[component]) for component in self.component_dirs])
        self.matched_files = {filename: {component: os.path.join(self.root_dir, component, filename) for component in self.component_dirs} for filename in common_filenames}

    def __len__(self):
        return len(self.matched_files)

    def __getitem__(self, idx):
        # Get the filename for the current index
        filename = list(self.matched_files.keys())[idx]

        # Load and transform images for each component
        images = {}
        for component, filepath in self.matched_files[filename].items():
            image = Image.open(filepath).convert("RGB")  # Load as RGB
            if self.transform:
                image = self.transform(image)
            images[component] = image

        return images
