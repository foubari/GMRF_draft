import os
import numpy as np
import torch
import glob
from fid.inception import InceptionV3
from fid.fid_score import get_activations
from fid.fid_score import calculate_frechet_distance
from sklearn.metrics import accuracy_score
from torchvision.utils import save_image
import shutil
from tqdm import tqdm
# from utils import unpack_data_polymnist
from statistics import mean



from PIL import Image

def unpack_data_polymnist(data, device='cuda'):
    data_nolabel = data[0]
    n_idxs = len(data_nolabel)
    return [data_nolabel[idx].to(device) for idx in range(n_idxs)], data[1].to(device)

def calculate_inception_features_for_gen_evaluation(inception_state_dict_path, device, dir_fid_base, datadir, dims=2048, batch_size=128):
    block_idx = InceptionV3.BLOCK_INDEX_BY_DIM[dims]
    model = InceptionV3([block_idx], path_state_dict=inception_state_dict_path).to(device)

    # 1) Compute real activations for m0..m4 as before
    for modality_num in range(5):
        modality = f"m{modality_num}"
        filename_act_real_calc = os.path.join(datadir, 'test', f"real_activations_{modality}.npy")
        if not os.path.exists(filename_act_real_calc):
            files_real_calc = glob.glob(os.path.join(datadir, 'test', modality, "*.png"))
            act_real_calc = get_activations(files_real_calc, model, device, batch_size, dims, verbose=False)
            np.save(filename_act_real_calc, act_real_calc)

    # 2) NEW: Compute real activations for "superpos"
    #    Make sure you have a folder datadir/test/superpos containing real superpos images
    filename_act_real_superpos = os.path.join(datadir, 'test', "real_activations_superpos.npy")
    if not os.path.exists(filename_act_real_superpos):
        files_real_superpos = glob.glob(os.path.join(datadir, 'test', "superpos", "*.png"))
        act_real_superpos = get_activations(files_real_superpos, model, device, batch_size, dims, verbose=False)
        np.save(filename_act_real_superpos, act_real_superpos)

    # 3) For prefix in ['random', 'm0', ..., 'm4', ALSO 'superpos'] or handle superpos separately
    #    Actually we only store generated images under random/ + m{i}/ + new superpos folder
    #    Let's do the same logic for each top-level
    for prefix in ['random', 'm0', 'm1', 'm2', 'm3', 'm4']:
        dir_gen = os.path.join(dir_fid_base, prefix)
        if not os.path.exists(dir_gen):
            raise RuntimeError('Invalid path: %s' % dir_gen)

        # For each target: 5 modalities + "superpos"
        for target in ['m0','m1','m2','m3','m4','superpos']:
            dir_target = os.path.join(dir_gen, target)
            if not os.path.isdir(dir_target):
                continue  # skip if folder not found
            files_gen = glob.glob(os.path.join(dir_target, "*.png"))
            filename_act = os.path.join(dir_gen, target + "_activations.npy")
            act_rand_gen = get_activations(files_gen, model, device, batch_size, dims, verbose=False)
            np.save(filename_act, act_rand_gen)
            
            
def create_superpos_images(fid_path):
    """
    Summation-based superpos:
      1) For random folder: gather random/m0..m4, sum each index -> save in random/superpos
      2) For each conditional folder mX: gather mX/m0..m4 -> sum -> mX/superpos
    Assumes each subfolder has the same filenames, e.g., 000000.png, 000001.png, etc.
    """
    # 1) Handle random
    random_dir = os.path.join(fid_path, "random")
    random_mod_folders = [os.path.join(random_dir, f"m{i}") for i in range(5)]
    random_superpos_dir = os.path.join(random_dir, "superpos")

    # We assume each m{i} folder has the same set of filenames
    filenames = os.listdir(random_mod_folders[0])  # e.g., [0000.png, 0001.png, ...]
    for fname in filenames:
        if not fname.endswith(".png"):
                continue
        imgs_sum = None
        # Sum across m0..m4
        for mod_folder in random_mod_folders:
            path_img = os.path.join(mod_folder, fname)
            if not os.path.exists(path_img):
                continue
            img = np.array(Image.open(path_img).convert("RGB"), dtype=np.float32)
            if imgs_sum is None:
                imgs_sum = img
            else:
                imgs_sum += img
        # Convert sum to valid range [0..255] or clamp
        imgs_sum = np.clip(imgs_sum, 0, 255).astype(np.uint8)
        # Save in superpos folder
        out_path = os.path.join(random_superpos_dir, fname)
        Image.fromarray(imgs_sum).save(out_path)

    # 2) Handle conditional folders: m0..m4
    for source_id in range(5):
        source_dir = os.path.join(fid_path, f"m{source_id}")
        cond_mod_folders = [os.path.join(source_dir, f"m{i}") for i in range(5)]
        cond_superpos_dir = os.path.join(source_dir, "superpos")

        # Again assume the same set of filenames in each subfolder
        filenames = os.listdir(cond_mod_folders[0])
        for fname in filenames:
            if not fname.endswith(".png"):
                continue
            imgs_sum = None
            for mod_folder in cond_mod_folders:
                path_img = os.path.join(mod_folder, fname)
                if not os.path.exists(path_img):
                    continue
                img = np.array(Image.open(path_img).convert("RGB"), dtype=np.float32)
                if imgs_sum is None:
                    imgs_sum = img
                else:
                    imgs_sum += img
            imgs_sum = np.clip(imgs_sum, 0, 255).astype(np.uint8)
            out_path = os.path.join(cond_superpos_dir, fname)
            Image.fromarray(imgs_sum).save(out_path)

    print("✅ Created superpos images by summing the 5 modalities.")

    
def calculate_fid_routine(model, test_loader,  args, datadir, fid_path, num_fid_samples, epoch=None, writer=None, device='cpu'):
    """
    Calculates FID scores for 5 existing modalities (random & conditional),
    then creates 'superpos' by summing the 5 images, and calculates FID again.
    """

    # 1) Create new directories for unconditional & conditional
    print(' Creating folders')
    for j in range(5):
        # random
        random_j = os.path.join(fid_path, 'random', f"m{j}")
        if os.path.exists(random_j):
            shutil.rmtree(random_j)
        os.makedirs(random_j)
        
        # conditional subfolders
        for i in range(5):
            cond_j_i = os.path.join(fid_path, f"m{j}", f"m{i}")
            if os.path.exists(cond_j_i):
                shutil.rmtree(cond_j_i)
            os.makedirs(cond_j_i)
            
        # Also ensure we have empty superpos folders:
        # random/superpos, m{j}/superpos
        random_superpos = os.path.join(fid_path, 'random', 'superpos')
        os.makedirs(random_superpos, exist_ok=True)

        cond_j_superpos = os.path.join(fid_path, f"m{j}", 'superpos')
        os.makedirs(cond_j_superpos, exist_ok=True)

    # 2) Generate unconditional images
    with torch.no_grad():
        print('Generate unconditional fid samples')
        for tranche in tqdm(range(num_fid_samples // 100)):
            model.generate_for_fid(fid_path, 100, tranche)  
            # This will populate random/m0..m4 with .png images

        # 3) Generate conditional images
        print('Generate conditional fid samples')
        total_cond = 0
        for i, dataT in tqdm(enumerate(test_loader), total=len(test_loader)):
            data, _ = unpack_data_polymnist(dataT, device=device)
            if total_cond < num_fid_samples:
                model.reconstruct_for_fid(data, fid_path, i)  
                # This populates m{source}/m{target} with .png images
                total_cond += data[0].size(0)

    # 4) NEW STEP: Create “superpos” images by summing the 5 modalities
    print('Superposing components')
    create_superpos_images(fid_path)

    # 5) Compute Inception features (includes superpos now)
    print('Computing Inception features')
    calculate_inception_features_for_gen_evaluation(args.inception_module_path, device, fid_path, datadir)

    # 6) FID calculation
    print('FID calculation')

    # We keep original random & cond FIDs
    fid_randm_list = []
    fid_condgen_list = []

    # NEW lists for superpos
    fid_randm_list_superpos = []
    fid_condgen_list_superpos = []

    # For each target = m0..m4, compute random & conditional FID
    for modality_target in tqdm([f"m{i}" for i in range(5)], total=5):
        file_activations_real = os.path.join(datadir, 'test', f"real_activations_{modality_target}.npy")
        feats_real = np.load(file_activations_real)

        # random
        file_activations_randgen = os.path.join(fid_path, 'random', f"{modality_target}_activations.npy")
        feats_randgen = np.load(file_activations_randgen)
        fid_randval = calculate_fid_torch(feats_real, feats_randgen)
        if epoch is not None:
            writer.add_scalar(f"FID/random/{modality_target}", fid_randval, epoch)
        fid_randm_list.append(fid_randval)

        # conditional
        fid_condgen_target_list = []
        for modality_source in [f"m{i}" for i in range(5)]:
            file_activations_gen = os.path.join(fid_path, modality_source, f"{modality_target}_activations.npy")
            feats_gen = np.load(file_activations_gen)
            fid_val = calculate_fid_torch(feats_real, feats_gen)
            if epoch is not None:
                writer.add_scalar(f"FID/{modality_source}/{modality_target}", fid_val, epoch)
            fid_condgen_target_list.append(fid_val)
        fid_condgen_list.append(mean(fid_condgen_target_list))

    # Original summary
    mean_fid_randm = mean(fid_randm_list)
    mean_fid_condgen = mean(fid_condgen_list)

    # === Now compute FID for superpos vs real superpos:
    file_act_real_superpos = os.path.join(datadir, 'test', 'real_activations_superpos.npy')
    feats_real_superpos = np.load(file_act_real_superpos)

    # 7) Random superpos FID
    file_activations_randgen_superpos = os.path.join(fid_path, 'random', 'superpos_activations.npy')
    feats_randgen_superpos = np.load(file_activations_randgen_superpos)
    fid_rand_superpos = calculate_fid_torch(feats_real_superpos, feats_randgen_superpos)
    fid_randm_list_superpos.append(fid_rand_superpos)

    # 8) Conditional superpos
    fid_condgen_superpos_all = []
    for modality_source in [f"m{i}" for i in range(5)]:
        file_activations_cond_superpos = os.path.join(fid_path, modality_source, "superpos_activations.npy")
        feats_cond_superpos = np.load(file_activations_cond_superpos)
        fid_val_superpos = calculate_fid_torch(feats_real_superpos, feats_cond_superpos)
        fid_condgen_superpos_all.append(fid_val_superpos)
        if epoch is not None:
            writer.add_scalar(f"FID/{modality_source}/superpos", fid_val_superpos, epoch)

    mean_fid_randm_superpos = mean(fid_randm_list_superpos)
    mean_fid_condgen_superpos = mean(fid_condgen_superpos_all)

    if epoch is not None:
        writer.add_scalar("FID/random_overallavg", mean_fid_randm, epoch)
        writer.add_scalar("FID/condgen_overallavg", mean_fid_condgen, epoch)
        writer.add_scalar("FID/random_superpos", mean_fid_randm_superpos, epoch)
        writer.add_scalar("FID/condgen_superpos", mean_fid_condgen_superpos, epoch)

    print("Mean Random FID:", mean_fid_randm)
    print("Mean Cond FID:", mean_fid_condgen)
    print("Mean Random FID (superpos):", mean_fid_randm_superpos)
    print("Mean Cond FID (superpos):", mean_fid_condgen_superpos)

    return mean_fid_randm, mean_fid_condgen, mean_fid_randm_superpos, mean_fid_condgen_superpos


def torch_cov(x):
    """
    Compute covariance matrix for tensor x.
    x: Tensor of shape (n_samples, n_features)
    Returns: Covariance matrix of shape (n_features, n_features)
    """
    n = x.size(0)
    mean = torch.mean(x, dim=0, keepdim=True)
    x_centered = x - mean
    # Note: using (n-1) for an unbiased estimate
    cov = (x_centered.t() @ x_centered) / (n - 1)
    return cov

def calculate_frechet_distance_torch(mu1, sigma1, mu2, sigma2, eps=1e-6):
    """
    Computes the Frechet Distance using PyTorch.
    Assumes that sigma1 and sigma2 are symmetric positive semi-definite.
    Adds safety measures (similar to NumPy's sqrtm approach) to handle near-singular cases.
    """
    diff = mu1 - mu2

    # 1) First attempt: compute product and do eigen-decomp
    prod = sigma1 @ sigma2
    prod = (prod + prod.t()) / 2  # Symmetrize for numerical stability
    eigvals, eigvecs = torch.linalg.eigh(prod)

    # 2) Check for numerical issues: if any eigvals are NaN or Inf, fallback
    if not torch.isfinite(eigvals).all():
        print("FID calculation produced non-finite eigenvalues; "
              f"adding eps={eps} to diagonals of covariances as a fallback.")

        eye = torch.eye(sigma1.size(0), dtype=sigma1.dtype, device=sigma1.device)
        sigma1 = sigma1 + eps * eye
        sigma2 = sigma2 + eps * eye

        # Recompute product and eigen-decomposition
        prod = sigma1 @ sigma2
        prod = (prod + prod.t()) / 2
        eigvals, eigvecs = torch.linalg.eigh(prod)

    # 3) Clamp negative eigenvalues (due to small numerical drift) to 0
    eigvals = torch.clamp(eigvals, min=0)

    # 4) Construct the matrix square root from eigen-decomp
    sqrt_prod = eigvecs @ torch.diag(torch.sqrt(eigvals)) @ eigvecs.t()
    tr_covmean = torch.trace(sqrt_prod)

    # 5) Compute the Frechet distance
    fid = diff.dot(diff) + torch.trace(sigma1) + torch.trace(sigma2) - 2.0 * tr_covmean
    return fid

def calculate_fid_torch(feats_real, feats_gen, device='cuda'):
    """
    Computes FID on GPU using PyTorch.
    feats_real and feats_gen: numpy arrays of shape (n_samples, n_features)
    """
    # Move features to torch tensors on the specified device
    feats_real_t = torch.tensor(feats_real, device=device, dtype=torch.float32)
    feats_gen_t = torch.tensor(feats_gen, device=device, dtype=torch.float32)
    
    # Compute means
    mu_real = torch.mean(feats_real_t, dim=0)
    mu_gen = torch.mean(feats_gen_t, dim=0)
    
    # Compute covariances
    sigma_real = torch_cov(feats_real_t)
    sigma_gen = torch_cov(feats_gen_t)
    
    # Calculate FID with safety measures
    fid = calculate_frechet_distance_torch(mu_real, sigma_real, mu_gen, sigma_gen)
    return fid.item()
