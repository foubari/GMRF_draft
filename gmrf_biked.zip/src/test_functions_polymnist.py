import os
import numpy as np
import torch
import glob
from fid.inception import InceptionV3
from fid.fid_score import get_activations
from fid.fid_score import calculate_frechet_distance
from sklearn.metrics import accuracy_score
from torchvision.utils import save_image
import shutil
from tqdm import tqdm
from utils import unpack_data_polymnist
from statistics import mean


def calculate_inception_features_for_gen_evaluation(inception_state_dict_path, device, dir_fid_base, datadir, dims=2048, batch_size=128):
    block_idx = InceptionV3.BLOCK_INDEX_BY_DIM[dims]

    model = InceptionV3([block_idx], path_state_dict=inception_state_dict_path)
    model = model.to(device)

    for moddality_num in range(5):
        moddality = 'm{}'.format(moddality_num)
        filename_act_real_calc = os.path.join(datadir, 'test','real_activations_{}.npy'.format(moddality))
        print('filename_act_real_calc',filename_act_real_calc)
        if not os.path.exists(filename_act_real_calc):
            files_real_calc = glob.glob(os.path.join(datadir,  'test', moddality, '*' + '.png'))
            act_real_calc = get_activations(files_real_calc, model, device, batch_size, dims, verbose=False)
            np.save(filename_act_real_calc, act_real_calc)

    for prefix  in ['random', 'm0', 'm1', 'm2', 'm3', 'm4']:
        dir_gen = os.path.join(dir_fid_base, prefix)
        if not os.path.exists(dir_gen):
            raise RuntimeError('Invalid path: %s' % dir_gen)
        for modality in ['m{}'.format(m) for m in range(5)]:
            files_gen = glob.glob(os.path.join(dir_gen, modality, '*' + '.png'))
            filename_act = os.path.join(dir_gen,
                                           modality + '_activations.npy')
            act_rand_gen = get_activations(files_gen, model, device, batch_size, dims, verbose=False)
            np.save(filename_act, act_rand_gen)



def load_inception_activations(flags, modality=None, num_modalities=2, conditionals=None):
    if modality is None:
        filename_real = os.path.join(flags.dir_gen_eval_fid_real, 'real_img_activations.npy');
        filename_random = os.path.join(flags.dir_gen_eval_fid_random, 'random_img_activations.npy')
        filename_conditional = os.path.join(flags.dir_gen_eval_fid_cond_gen, 'conditional_img_activations.npy')
        feats_real = np.load(filename_real);
        feats_random = np.load(filename_random);
        feats_cond = np.load(filename_conditional);
        feats = [feats_real, feats_random, feats_cond];
    else:
        filename_real = os.path.join(flags.dir_gen_eval_fid_real, 'real_' + modality + '_activations.npy');
        filename_random = os.path.join(flags.dir_gen_eval_fid_random, 'random_sampling_' + modality + '_activations.npy')
        feats_real = np.load(filename_real);
        feats_random = np.load(filename_random);

        #if num_modalities == 2:
            #filename_cond_gen = os.path.join(flags.dir_gen_eval_fid_cond_gen, 'cond_gen_' + modality + '_activations.npy')
            #feats_cond_gen = np.load(filename_cond_gen);
            #feats = [feats_real, feats_random, feats_cond_gen];
        #elif num_modalities > 2:
            #if conditionals is None:
                #raise RuntimeError('conditionals are needed for num(M) > 2...')
        feats_cond_1a2m = dict()
        for k, key in enumerate(conditionals[0].keys()):
            filename_cond_1a2m = os.path.join(conditionals[0][key], key + '_' + modality + '_activations.npy')
            feats_cond_key = np.load(filename_cond_1a2m);
            feats_cond_1a2m[key] = feats_cond_key
        feats = [feats_real, feats_random, feats_cond_1a2m] #, feats_cond_2a1m, feats_cond_dyn_prior_2a1m];
        #else:
            #print('combinations of feature names and number of modalities is not correct');
    return feats;

def calculate_fid(feats_real, feats_gen):
    mu_real = np.mean(feats_real, axis=0)
    sigma_real = np.cov(feats_real, rowvar=False)
    mu_gen = np.mean(feats_gen, axis=0)
    sigma_gen = np.cov(feats_gen, rowvar=False)
    fid = calculate_frechet_distance(mu_real, sigma_real, mu_gen, sigma_gen)
    return fid;


def calculate_fid_dict(feats_real, dict_feats_gen):
    dict_fid = dict();
    for k, key in enumerate(dict_feats_gen.keys()):
        feats_gen = dict_feats_gen[key];
        dict_fid[key] = calculate_fid(feats_real, feats_gen);
    return dict_fid;


def get_clf_activations(flags, data, model):
    model.eval();
    act = model.get_activations(data);
    act = act.cpu().data.numpy().reshape(flags.batch_size, -1)
    return act;

def classify_latent_representations(clf_lr, data, labels):
    print('Clslfying lrs')
    gt = np.argmax(labels, axis=1).astype(int)
    accuracies = dict()
    for k, data_k in enumerate(data):         
        data_rep_u, data_rep_w, data_rep_z = data_k

        clf_key_u = 'm' + str(k) + '_'+'u'
        clf_lr_rep_u = clf_lr[clf_key_u];
        y_pred_rep_u = clf_lr_rep_u.predict(data_rep_u);
        accuracy_rep_u = accuracy_score(gt, y_pred_rep_u.ravel());
        accuracies[clf_key_u] = accuracy_rep_u;

        clf_key_z = 'm' + str(k) + '_' + 'z'
        clf_lr_rep_z = clf_lr[clf_key_z];
        y_pred_rep_z = clf_lr_rep_z.predict(data_rep_z);
        accuracy_rep_z = accuracy_score(gt, y_pred_rep_z.ravel());
        accuracies[clf_key_z] = accuracy_rep_z;

        clf_key_w = 'm' + str(k) + '_' + 'w'
        clf_lr_rep_w = clf_lr[clf_key_w];
        y_pred_rep_w = clf_lr_rep_w.predict(data_rep_w);
        accuracy_rep_w = accuracy_score(gt, y_pred_rep_w.ravel());
        accuracies[clf_key_w] = accuracy_rep_w;
    return accuracies;



def calculate_fid_routine(model, test_loader,  args, datadir, fid_path, num_fid_samples, epoch=None, writer= None, device='cpu'):
    "Calculates FID scores"
    total_cond = 0
    # Create new directories for conditional FIDs
    print(' Creating folders')
    for j in [0, 1, 2, 3, 4]:
        if os.path.exists(os.path.join(fid_path, 'random', 'm{}'.format(j))):
            shutil.rmtree(os.path.join(fid_path, 'random', 'm{}'.format(j)))
            os.makedirs(os.path.join(fid_path, 'random', 'm{}'.format(j)))
        else:
            os.makedirs(os.path.join(fid_path, 'random', 'm{}'.format(j)))
        for i in [0, 1, 2, 3, 4]:
            if os.path.exists(os.path.join(fid_path, 'm{}'.format(j), 'm{}'.format(i))):
                shutil.rmtree(os.path.join(fid_path, 'm{}'.format(j), 'm{}'.format(i)))
                os.makedirs(os.path.join(fid_path, 'm{}'.format(j), 'm{}'.format(i)))
            else:
                os.makedirs(os.path.join(fid_path, 'm{}'.format(j), 'm{}'.format(i)))
    
    with torch.no_grad():
        print('Generate unconditional fid samples')
        for tranche in tqdm(range(num_fid_samples // 100)):
            model.generate_for_fid(fid_path, 100, tranche)
            
        print('Generate conditional fid samples')
        for i, dataT in tqdm(enumerate(test_loader), total = len(test_loader)):
            data, _ = unpack_data_polymnist(dataT, device=device)#model.device)
            if total_cond < num_fid_samples:
                model.reconstruct_for_fid(data, fid_path, i)
                total_cond += data[0].size(0)
        calculate_inception_features_for_gen_evaluation(args.inception_module_path, device, fid_path, datadir)
        #model.device in the original code
        print('FID calculation')
        fid_randm_list = []
        fid_condgen_list = []
        for modality_target in tqdm(['m{}'.format(m) for m in range(5)], total=5):
            file_activations_real = os.path.join(datadir, 'test',
                                                 'real_activations_{}.npy'.format(modality_target))
            feats_real = np.load(file_activations_real)
            file_activations_randgen = os.path.join(fid_path, 'random',
                                                    modality_target + '_activations.npy')
            feats_randgen = np.load(file_activations_randgen)
            fid_randval = calculate_fid(feats_real, feats_randgen)
            if epoch != None:
                writer.add_scalar("FID/{}/{}".format('random', modality_target), fid_randval, epoch)
            fid_randm_list.append(fid_randval)
            fid_condgen_target_list = []
            for modality_source in ['m{}'.format(m) for m in range(5)]:
                file_activations_gen = os.path.join(fid_path, modality_source,
                                                    modality_target + '_activations.npy')
                feats_gen = np.load(file_activations_gen)
                fid_val = calculate_fid(feats_real, feats_gen)
                if epoch != None:
                    writer.add_scalar("FID/{}/{}".format(modality_source, modality_target), fid_val, epoch)
                fid_condgen_target_list.append(fid_val)
            fid_condgen_list.append(mean(fid_condgen_target_list))
        mean_fid_condgen = mean(fid_condgen_list)
        mean_fid_randm = mean(fid_randm_list)
        if epoch != None:
            writer.add_scalar("FID/random_overallavg", mean_fid_randm, epoch)
            writer.add_scalar("FID/condionalgeneration_overallavg", mean_fid_condgen, epoch)
        print("Mean Random FID", mean_fid_randm)
        print("Mean Cond FID", mean_fid_condgen)
        return mean_fid_randm, mean_fid_condgen
    
    if os.path.exists(fid_path):
        shutil.rmtree(fid_path)
        os.makedirs(fid_path)