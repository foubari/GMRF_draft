import math
import os
import shutil
import sys
import time
import torch
import torch.distributions as dist
import torch.nn.functional as F
import random
import torch.nn as nn

from torch.distributions.multivariate_normal import MultivariateNormal
from torch.distributions.exponential import Exponential



def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

# Classes
class Constants(object):
    eta = 1e-6
    log2 = math.log(2)
    log2pi = math.log(2 * math.pi)
    logceilc = 88  # largest cuda v s.t. exp(v) < inf
    logfloorc = -104  # smallest cuda v s.t. exp(v) > 0
    relu_shift = 1
    exp_shift = 0
    exp_factor = 1


# https://stackoverflow.com/questions/14906764/how-to-redirect-stdout-to-both-file-and-console-with-scripting
class Logger(object):
    def __init__(self, filename, mode="a"):
        self.terminal = sys.stdout
        self.log = open(filename, mode)

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        # this flush method is needed for python 3 compatibility.
        # this handles the flush command by doing nothing.
        # you might want to specify some extra behavior here.
        pass


class Timer:
    def __init__(self, name):
        self.name = name

    def __enter__(self):
        self.begin = time.time()
        return self

    def __exit__(self, *args):
        self.end = time.time()
        self.elapsed = self.end - self.begin
        self.elapsedH = time.gmtime(self.elapsed)
        print('====> [{}] Time: {:7.3f}s or {}'
              .format(self.name,
                      self.elapsed,
                      time.strftime("%H:%M:%S", self.elapsedH)))

        
def initialize_weights(m, method='xavier'):
    """
    Initialize model weights.

    Arguments:
    - m: torch module (typically a layer)
    - method: str, type of initialization ('xavier', 'kaiming', 'orthogonal', 'zero', 'uniform')
    """
    if isinstance(m, nn.Linear):

        # Xavier (Glorot) Initialization
        if method == 'xavier':
            init.xavier_uniform_(m.weight)
            m.bias.data.fill_(0.01)

        # Kaiming (He) Initialization
        elif method == 'kaiming':
            init.kaiming_uniform_(m.weight, nonlinearity='relu')
            m.bias.data.fill_(0.01)

        # Orthogonal Initialization
        elif method == 'orthogonal':
            init.orthogonal_(m.weight)
            m.bias.data.fill_(0.01)

        # Zero Initialization
        elif method == 'zero':
            m.weight.data.fill_(0)
            m.bias.data.fill_(0)

        # Uniform Random Initialization
        elif method == 'uniform':
            m.weight.data.uniform_(-1, 1)
            m.bias.data.fill_(0.01)

        else:
            raise ValueError(f"Unknown initialization method {method}")

# Functions
def save_vars(vs, filepath):
    """
    Saves variables to the given filepath in a safe manner.
    """
    if os.path.exists(filepath):
        shutil.copyfile(filepath, '{}.old'.format(filepath))
    torch.save(vs, filepath)


def save_model(model, filepath):
    """
    To load a saved model, simply use
    `model.load_state_dict(torch.load('path-to-saved-model'))`.
    """
    save_vars(model.state_dict(), filepath)
    if hasattr(model, 'vaes'):
        for vae in model.vaes:
            fdir, fext = os.path.splitext(filepath)
            save_vars(vae.state_dict(), fdir + '_' + vae.modelName + fext)

def save_model_light(model, filepath):
    """
    To load a saved model, simply use
    `model.load_state_dict(torch.load('path-to-saved-model'))`.
    """
    save_vars(model.state_dict(), filepath)


def is_multidata(dataB):
    return isinstance(dataB, list) or isinstance(dataB, tuple)


def unpack_data(dataB, device='cuda'):
    # dataB :: (Tensor, Idx) | [(Tensor, Idx)]
    """ Unpacks the data batch object in an appropriate manner to extract data """
    if is_multidata(dataB):
        if torch.is_tensor(dataB[0]):
            if torch.is_tensor(dataB[1]):
                return dataB[0].to(device)  # mnist, svhn, cubI
            elif is_multidata(dataB[1]):
                return dataB[0].to(device), dataB[1][0].to(device)  # cubISft
            else:
                raise RuntimeError('Invalid data format {} -- check your dataloader!'.format(type(dataB[1])))

        elif is_multidata(dataB[0]):
            return [d.to(device) for d in list(zip(*dataB))[0]]  # mnist-svhn, cubIS
        else:
            raise RuntimeError('Invalid data format {} -- check your dataloader!'.format(type(dataB[0])))
    elif torch.is_tensor(dataB):
        return dataB.to(device)
    else:
        raise RuntimeError('Invalid data format {} -- check your dataloader!'.format(type(dataB)))

def unpack_data_polymnist(data, device='cuda'):
    data_nolabel = data[0]
    n_idxs = len(data_nolabel)
    return [data_nolabel[idx].to(device) for idx in range(n_idxs)], data[1].to(device)

def unpack_data_epures(data, device='cuda'):
    n_idxs = len(data)
    return [data[idx].to(device) for idx in range(n_idxs)],

# def unpack_data_biked(data, device = 'cuda'):
#     component_names = ['crank', 'frame', 'handle', 'saddle', 'wheel']
#     return [data[c].to(device) for c in component_names]
def unpack_data_biked(data, device = 'cuda'):
    # component_names = ['m0', 'm1', 'm2', 'm3', 'm4']
    return [d[0].to(device) for d in data]

def get_10_polyMNIST_samples(svhnmnist, num_testing_images, device):
    samples = []
    for i in range(10):
        while True:
            imgs, target = svhnmnist.__getitem__(random.randint(0, num_testing_images - 1))
            img_1, img_2, img_3, img_4, img_5 = imgs
            if target == i:
                img_1 = img_1.to(device)
                img_2 = img_2.to(device)
                img_3 = img_3.to(device)
                img_4 = img_4.to(device)
                img_5 = img_5.to(device)
                samples.append((img_1, img_2, img_3, img_4, img_5, target))
                break
    outputs = []
    for mod in range(5):
        outputs_mod = [samples[digit][mod] for digit in range(10)]
        outputs.append(torch.stack(outputs_mod, dim=0))
    return outputs


def get_mean(d, K=100):
    """
    Extract the `mean` parameter for given distribution.
    If attribute not available, estimate from samples.
    """
    try:
        mean = d.mean
    except NotImplementedError:
        samples = d.rsample(torch.Size([K]))
        mean = samples.mean(0)
    return mean


def log_mean_exp(value, dim=0, keepdim=False):
    return torch.logsumexp(value, dim, keepdim=keepdim) - math.log(value.size(dim))


def kl_divergence(d1, d2, K=100):
    """Computes closed-form KL if available, else computes a MC estimate."""
    if (type(d1), type(d2)) in torch.distributions.kl._KL_REGISTRY:
        return torch.distributions.kl_divergence(d1, d2)
    else:
        samples = d1.rsample(torch.Size([K]))
        return (d1.log_prob(samples) - d2.log_prob(samples)).mean(0)


def pdist(sample_1, sample_2, eps=1e-5):
    """Compute the matrix of all squared pairwise distances. Code
    adapted from the torch-two-sample library (added batching).
    You can find the original implementation of this function here:
    https://github.com/josipd/torch-two-sample/blob/master/torch_two_sample/util.py

    Arguments
    ---------
    sample_1 : torch.Tensor or Variable
        The first sample, should be of shape ``(batch_size, n_1, d)``.
    sample_2 : torch.Tensor or Variable
        The second sample, should be of shape ``(batch_size, n_2, d)``.
    norm : float
        The l_p norm to be used.
    batched : bool
        whether data is batched

    Returns
    -------
    torch.Tensor or Variable
        Matrix of shape (batch_size, n_1, n_2). The [i, j]-th entry is equal to
        ``|| sample_1[i, :] - sample_2[j, :] ||_p``."""
    if len(sample_1.shape) == 2:
        sample_1, sample_2 = sample_1.unsqueeze(0), sample_2.unsqueeze(0)
    B, n_1, n_2 = sample_1.size(0), sample_1.size(1), sample_2.size(1)
    norms_1 = torch.sum(sample_1 ** 2, dim=-1, keepdim=True)
    norms_2 = torch.sum(sample_2 ** 2, dim=-1, keepdim=True)
    norms = (norms_1.expand(B, n_1, n_2)
             + norms_2.transpose(1, 2).expand(B, n_1, n_2))
    distances_squared = norms - 2 * sample_1.matmul(sample_2.transpose(1, 2))
    return torch.sqrt(eps + torch.abs(distances_squared)).squeeze()  # batch x K x latent


def NN_lookup(emb_h, emb, data):
    indices = pdist(emb.to(emb_h.device), emb_h).argmin(dim=0)
    # indices = torch.tensor(cosine_similarity(emb, emb_h.cpu().numpy()).argmax(0)).to(emb_h.device).squeeze()
    return data[indices]


class FakeCategorical(dist.Distribution):
    support = dist.constraints.real
    has_rsample = True

    def __init__(self, locs):
        self.logits = locs
        self._batch_shape = self.logits.shape

    @property
    def mean(self):
        return self.logits

    def sample(self, sample_shape=torch.Size()):
        with torch.no_grad():
            return self.rsample(sample_shape)

    def rsample(self, sample_shape=torch.Size()):
        return self.logits.expand([*sample_shape, *self.logits.shape]).contiguous()

    def log_prob(self, value):
        # value of shape (K, B, D)
        lpx_z = -F.cross_entropy(input=self.logits.view(-1, self.logits.size(-1)),
                                 target=value.expand(self.logits.size()[:-1]).long().view(-1),
                                 reduction='none',
                                 ignore_index=0)

        return lpx_z.view(*self.logits.shape[:-1])
        # it is inevitable to have the word embedding dimension summed up in
        # cross-entropy loss ($\sum -gt_i \log(p_i)$ with most gt_i = 0, We adopt the
        # operationally equivalence here, which is summing up the sentence dimension
        # in objective.

class NonLinearLatent_Classifier(nn.Module):
    """ Generate latent parameters for SVHN image data. """

    def __init__(self, in_n):
        super(NonLinearLatent_Classifier, self).__init__()
        self.mlp = nn.Sequential(nn.Linear(in_n, 64), nn.ReLU(inplace=True),
                                 nn.Linear(64, 10))

    def forward(self, x):
        return self.mlp(x)
    
    
def assemble_covariance_matrix(mu_list, chol_list, off_diag_coeffs, modalities_dim):
    # Total dimension of the assembled matrix.
    full_dim = sum(modalities_dim)

    # Initialize a matrix with zeros, of shape (batch_size, full_dim, full_dim).
    full_matrix = torch.zeros((mu_list[0].shape[0], full_dim, full_dim))

    # ------------------------------
    # 1. Fill in the diagonal blocks
    # ------------------------------

    start_idx = 0
    for i, dim in enumerate(modalities_dim):
        # For each modality, place its Cholesky diagonal block in the main matrix.
        full_matrix[:, start_idx:start_idx+dim, start_idx:start_idx+dim] = chol_list[i]

        # Move the starting index by the dimension of the current modality to position for the next modality.
        start_idx += dim

    # ----------------------------------------------
    # 2. Calculate the offsets for each modality block
    # This will be helpful in placing off-diagonal blocks
    # ----------------------------------------------

    offsets = [0]  # Starting from the beginning of the matrix.
    for dim in modalities_dim[:-1]:
        offsets.append(offsets[-1] + dim)

    # ----------------------------------------------
    # 3. Extract and place off-diagonal blocks
    # ----------------------------------------------

    start_idx = 0  # Reset starting index for off-diagonal coeffs extraction.
    for i, offset in enumerate(offsets[:-1]):
        # Compute how many elements are needed to fill the lines below the ith block.
        # For visualization, consider the matrix representation with blocks shown as 'x' and unfilled spaces as '-'
        # e.g., for 3 modalities:
        # [x x - - - - - - -]
        # [x x - - - - - - -]
        # [- - x x x - - - -]
        # [- - x x x - - - -]
        # [- - x x x - - - -]
        # [- - - - - x x x x]
        # [- - - - - x x x x]
        # [- - - - - x x x x]
        # [- - - - - x x x x]
        #
        # When on the first block (2x2), we need elements for the next two blocks below it (2x3 and 2x4 respectively).
        end_idx = start_idx + modalities_dim[i] * (full_dim - offset - modalities_dim[i])

        # Extract the block of coefficients for the current modality.
        block = off_diag_coeffs[:, start_idx:end_idx].reshape(mu_list[0].shape[0], modalities_dim[i], -1)

        # Place the transpose of the block in the main matrix to fill the lower triangular elements.
        full_matrix[:, offset+modalities_dim[i]:, offset:offset+modalities_dim[i]] = block.transpose(-2, -1)

        # Move the starting index to end index for the next iteration.
        start_idx = end_idx

    return full_matrix

def assemble_covariance_matrix_corrected(mu_list, sigma_list, off_diag_coeffs, modalities_dim, epsilon=0.9, delta=1e-6):
    """
    Assembles the covariance matrix for a multimodal VAE, ensuring symmetry and positive definiteness.
    
    Parameters:
    - mu_list: List of tensors, each of shape (batch_size, dim_k), mean vectors from modality encoders.
    - sigma_list: List of tensors, each of shape (batch_size, dim_k, dim_k), diagonal covariance matrices from modality encoders.
    - off_diag_coeffs: Tensor of shape (batch_size, num_off_diag_elements), output from the global encoder.
    - modalities_dim: List of ints, dimensions of each modality.
    - epsilon: Scalar or Tensor of shape (total_dim,), with values less than 1.
    - delta: Small positive scalar to prevent division by zero.

    Returns:
    - covariance_matrix: Tensor of shape (batch_size, total_dim, total_dim), the assembled covariance matrix.
    """
    # Total dimension of the assembled matrix
    total_dim = sum(modalities_dim)
    batch_size = mu_list[0].shape[0]
    device = mu_list[0].device

    # 1. Assemble Lambda, the big diagonal matrix from sigma_list
    # Extract diagonal elements from each sigma matrix
    sigma_diags = [torch.diagonal(sigma, dim1=-2, dim2=-1) for sigma in sigma_list]  # Each of shape (batch_size, dim_k)
    
    # Concatenate diagonals to form Lambda_diag
    v = torch.cat(sigma_diags, dim=1)  # Shape: (batch_size, total_dim)

    # 2. Assemble M from off_diag_coeffs
    # Initialize M with zeros
    M = torch.zeros((batch_size, total_dim, total_dim), device=device)

    # Compute start and end indices for each modality
    start_indices = []
    end_indices = []
    start = 0
    for dim in modalities_dim:
        start_indices.append(start)
        end = start + dim
        end_indices.append(end)
        start = end

    # Prepare to fill M
    num_modalities = len(modalities_dim)
    off_diag_block_sizes = []
    modality_pairs = []
    for i in range(1, num_modalities):
        for j in range(i):
            block_size = modalities_dim[i] * modalities_dim[j]
            off_diag_block_sizes.append(block_size)
            modality_pairs.append((i, j))

    # Compute cumulative sum to get offsets
    off_diag_block_starts = [0]
    for size in off_diag_block_sizes:
        off_diag_block_starts.append(off_diag_block_starts[-1] + size)
    off_diag_block_starts = off_diag_block_starts[:-1]  # Exclude the last cumulative sum

    # Fill M with off-diagonal blocks
    for block_idx, (i, j) in enumerate(modality_pairs):
        start = off_diag_block_starts[block_idx]
        end = start + off_diag_block_sizes[block_idx]
        # Extract the block of coefficients
        block_coeffs = off_diag_coeffs[:, start:end]  # Shape: (batch_size, block_size)
        # Reshape to (batch_size, modalities_dim[i], modalities_dim[j])
        block_coeffs = block_coeffs.view(batch_size, modalities_dim[i], modalities_dim[j])
        # Place in M at positions (i, j) and (j, i) to ensure symmetry
        M[:, start_indices[i]:end_indices[i], start_indices[j]:end_indices[j]] = block_coeffs
        M[:, start_indices[j]:end_indices[j], start_indices[i]:end_indices[i]] = block_coeffs.transpose(1, 2)

    # Ensure M is symmetric (should already be symmetric due to the above step)
    # M = (M + M.transpose(1, 2)) / 2

    # 3. Compute s_i = sum_{j != i} |M_{ij}|
    s = torch.sum(torch.abs(M), dim=2) - torch.abs(torch.diagonal(M, dim1=1, dim2=2))
    s = s + delta  # Add delta to prevent division by zero

    # 4. Compute alpha_i
    if isinstance(epsilon, float) or isinstance(epsilon, int):
        epsilon = torch.full_like(v, epsilon)
    else:
        epsilon = epsilon.to(device)

    alpha = torch.minimum(torch.ones_like(s), (v * epsilon) / s)  # Shape: (batch_size, total_dim)

    # 5. Compute alpha_{ij} = sqrt(alpha_i * alpha_j)
    alpha_i_sqrt = torch.sqrt(alpha)
    alpha_matrix = alpha_i_sqrt.unsqueeze(2) * alpha_i_sqrt.unsqueeze(1)  # Shape: (batch_size, total_dim, total_dim)

    # 6. Scale M symmetrically
    M_adjusted = M * alpha_matrix

    # 7. Construct the covariance matrix
    covariance_matrix = torch.diag_embed(v) + M_adjusted  # Shape: (batch_size, total_dim, total_dim)

    return covariance_matrix

def sample_generalized_hyperbolic(mu, scale_tril, n_samples=1):
    """
    Samples from a generalized hyperbolic distribution parameterized either by batched means and
    scale_trils or by single mean and scale_tril for multiple samples.

    Parameters:
    - mu (torch.Tensor): Mean of the distribution; could be [dimensions] or [batch_size, dimensions].
    - scale_tril (torch.Tensor): Cholesky decomposition of the covariance matrix; could be
      [dimensions, dimensions] or [batch_size, dimensions, dimensions].
    - n_samples (int): Number of samples to generate per batch element.

    Returns:
    - samples (torch.Tensor): Samples generated from the distribution; shape [n_samples, batch_size, dimensions]
      if batched input, or [n_samples, dimensions] if single input.
    """

    # Check if the input is batched
    if mu.dim() == 1:
        # Input is not batched, expand dimensions to simulate batch size of 1
        mu = mu.unsqueeze(0)
        scale_tril = scale_tril.unsqueeze(0)

    batch_size, dimensions = mu.shape

    # Expand W to match the batch size and sample size, [n_samples, batch_size, 1]
    w = Exponential(1.0).sample((n_samples, batch_size, 1)).to(mu.device)

    # Sampling from the standard multivariate normal distribution for each batch
    x = MultivariateNormal(torch.zeros(dimensions, device=mu.device), scale_tril=scale_tril).rsample((n_samples,))

    # Calculating samples
    samples = torch.sqrt(w) * x + w * mu.unsqueeze(0)

    if mu.shape[0] == 1:
        # If the original input was not batched, remove the batch dimension
        samples = samples.squeeze(1)

    return samples
