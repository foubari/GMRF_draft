import os
import numpy as np
import torch
import glob
import shutil
from statistics import mean
from tqdm import tqdm
from utils import unpack_data_biked

# fid/ submodules
from fid.inception import InceptionV3
from fid.fid_score import get_activations
from fid.fid_score import calculate_frechet_distance

######################################
# Biked dataset modalities
######################################
modality_names = ['crank', 'frame', 'handle', 'saddle', 'wheel']

def calculate_frechet_distance_custom(mu1, sigma1, mu2, sigma2):
    """Same as fid_score.calculate_frechet_distance, but you could inline or adapt if needed."""
    return calculate_frechet_distance(mu1, sigma1, mu2, sigma2)

def calculate_fid(feats_real, feats_gen):
    """
    Calculates FID between two sets of activations.
    """
    mu_real = np.mean(feats_real, axis=0)
    sigma_real = np.cov(feats_real, rowvar=False)
    mu_gen = np.mean(feats_gen, axis=0)
    sigma_gen = np.cov(feats_gen, rowvar=False)
    fid = calculate_frechet_distance_custom(mu_real, sigma_real, mu_gen, sigma_gen)
    return fid

def calculate_inception_features_for_gen_evaluation(inception_state_dict_path,
                                                   device,
                                                   dir_fid_base,
                                                   datadir,
                                                   dims=2048,
                                                   batch_size=128):
    """
    Computes inception features (activations) for:
      - Real images in `datadir/test/<modality>`
      - Generated images in `dir_fid_base/<prefix>/<modality>`
    And saves them as .npy files.
    """
    block_idx = InceptionV3.BLOCK_INDEX_BY_DIM[dims]
    model = InceptionV3([block_idx], path_state_dict=inception_state_dict_path)
    model = model.to(device)

    # 1) Real Activations
    #    We assume each real modality is in: datadir/test/{modality}/*.png
    #    Then store activations in: datadir/test/real_activations_{modality}.npy
    for modality in modality_names:
        filename_act_real = os.path.join(datadir,  f'real_activations_{modality}.npy')
        if not os.path.exists(filename_act_real):
            # Gather all real PNG images
            real_files = glob.glob(os.path.join(datadir,  modality, '*.png'))
            print(f"[INFO] Computing real activations for modality='{modality}' with {len(real_files)} images...")
            act_real = get_activations(real_files, model, device, batch_size, dims, verbose=False)
            np.save(filename_act_real, act_real)
        else:
            print(f"[SKIP] Real activations exist: {filename_act_real}")

    # 2) Generated Activations
    #    Typically, the script stores unconditional (random) images in 'random/<modality>',
    #    and conditional images in '{source_modality}/{target_modality}'.
    #    So we read from:
    #        dir_fid_base / prefix / {modality} / *.png
    #    where prefix in ['random', 'crank', 'frame', ...] (the source modalities).
    prefix_list = ['random'] + modality_names
    for prefix in prefix_list:
        dir_gen = os.path.join(dir_fid_base, prefix)
        if not os.path.exists(dir_gen):
            raise RuntimeError(f"Invalid path for generated images: {dir_gen}")

        for modality in modality_names:
            gen_files = glob.glob(os.path.join(dir_gen, modality, '*.png'))
            if len(gen_files) == 0:
                print(f"[WARNING] No generated images found in {dir_gen}/{modality}")
                continue

            filename_act_gen = os.path.join(dir_gen, f"{modality}_activations.npy")
            print(f"[INFO] Computing generated activations for '{prefix}/{modality}' with {len(gen_files)} images...")
            act_gen = get_activations(gen_files, model, device, batch_size, dims, verbose=False)
            np.save(filename_act_gen, act_gen)

def calculate_fid_routine(model,
                          test_loader,
                          args,
                          datadir,
                          fid_path,
                          num_fid_samples,
                          epoch=None,
                          writer=None,
                          device='cpu'):
    """
    Main routine to:
      1) Create directories for unconditional & conditional FID samples
      2) Generate images via model (unconditional + conditional)
      3) Compute Inception activations
      4) Calculate and log FID scores
    """
    print("[INFO] Setting up FID directories...")

    # Make sure there's a 'random' folder and each modality subfolder
    # Also for conditional: each source_modality folder, each target_modality subfolder
    if not os.path.exists(fid_path):
        os.makedirs(fid_path, exist_ok=True)

    # Remove & recreate random/<modality> subdirs
    for mod in modality_names:
        random_subdir = os.path.join(fid_path, 'random', mod)
        if os.path.exists(random_subdir):
            shutil.rmtree(random_subdir)
        os.makedirs(random_subdir, exist_ok=True)

    # Remove & recreate <source>/<target> subdirs for each possible pair
    for source in modality_names:
        source_path = os.path.join(fid_path, source)
        for target in modality_names:
            target_subdir = os.path.join(source_path, target)
            if os.path.exists(target_subdir):
                shutil.rmtree(target_subdir)
            os.makedirs(target_subdir, exist_ok=True)

    # ---------------------------------------------------------
    # Generate unconditional & conditional samples for FID
    # ---------------------------------------------------------
    total_cond = 0
    with torch.no_grad():
        print("[INFO] Generating unconditional (random) samples...")
        # Typically, model.generate_for_fid writes images into fid_path/random/<modality>/
        batch_size_gen = 100
        steps = num_fid_samples // batch_size_gen
        for tranche in tqdm(range(steps), desc="Uncond"):
            model.generate_for_fid(fid_path, batch_size_gen, tranche)

        print("[INFO] Generating conditional samples...")
        # model.reconstruct_for_fid should store images in fid_path/<source>/<target> subdirs
        for i, dataT in tqdm(enumerate(test_loader), total=len(test_loader), desc="Cond"):
            # Replace with your custom function if needed:
            # e.g. data, _ = unpack_data_biked(dataT, device=device)
            data= unpack_data_biked(dataT, device=device)
            if total_cond < num_fid_samples:
                for d in data:
                    print(d.shape)
                model.reconstruct_for_fid(data, fid_path, i)
                # If data[0] is the batch for the first modality, then data[0].size(0) is the batch size
                total_cond += data[0].size(0)

    # ---------------------------------------------------------
    # Compute Inception features (real & generated)
    # ---------------------------------------------------------
    print("[INFO] Computing Inception features for real & generated images...")
    calculate_inception_features_for_gen_evaluation(
        inception_state_dict_path=args.inception_module_path,
        device=device,
        dir_fid_base=fid_path,
        datadir=datadir
    )

    # ---------------------------------------------------------
    # Calculate FID (random vs. real) and (conditional vs. real)
    # ---------------------------------------------------------
    print("[INFO] Calculating FID scores...")
    fid_random_list = []
    fid_condgen_list = []

    for modality_target in tqdm(modality_names, desc="FID Computation"):
        # Load the real activations
        real_acts_path = os.path.join(datadir, f'real_activations_{modality_target}.npy')
        feats_real = np.load(real_acts_path)

        # 1) FID for unconditional (random) generation
        rand_acts_path = os.path.join(fid_path, 'random', f"{modality_target}_activations.npy")
        if os.path.exists(rand_acts_path):
            feats_rand = np.load(rand_acts_path)
            fid_random_val = calculate_fid(feats_real, feats_rand)
        else:
            print(f"[WARNING] No random activations found for '{modality_target}'. Setting FID to NaN.")
            fid_random_val = float('nan')

        if writer is not None and epoch is not None:
            writer.add_scalar(f"FID/random/{modality_target}", fid_random_val, epoch)
        fid_random_list.append(fid_random_val)

        # 2) FID for each conditional generation (source->target)
        fid_per_target = []
        for modality_source in modality_names:
            gen_acts_path = os.path.join(fid_path, modality_source, f"{modality_target}_activations.npy")
            if os.path.exists(gen_acts_path):
                feats_cond = np.load(gen_acts_path)
                fid_cond_val = calculate_fid(feats_real, feats_cond)
            else:
                print(f"[WARNING] No conditional activations found for '{modality_source}->{modality_target}'. Setting FID to NaN.")
                fid_cond_val = float('nan')

            if writer is not None and epoch is not None:
                writer.add_scalar(f"FID/{modality_source}/{modality_target}", fid_cond_val, epoch)

            fid_per_target.append(fid_cond_val)

        # We'll store the average across all sources for each target
        fid_condgen_list.append(mean(fid_per_target))

    mean_fid_rand = mean(fid_random_list) if len(fid_random_list) > 0 else float('nan')
    mean_fid_cond = mean(fid_condgen_list) if len(fid_condgen_list) > 0 else float('nan')

    if writer is not None and epoch is not None:
        writer.add_scalar("FID/random_overallavg", mean_fid_rand, epoch)
        writer.add_scalar("FID/conditional_overallavg", mean_fid_cond, epoch)

    print(f"[RESULT] Mean Random FID = {mean_fid_rand:.4f}")
    print(f"[RESULT] Mean Conditional FID = {mean_fid_cond:.4f}")

    # Optionally, clean up the fid_path if you want to remove the images after calculation
    # (comment out if you prefer to keep them)
    # if os.path.exists(fid_path):
    #     shutil.rmtree(fid_path)
    #     os.makedirs(fid_path, exist_ok=True)

    return mean_fid_rand, mean_fid_cond
