# PolyMNIST model specification
import torch
import torch.distributions as dist
import torch.nn as nn
import torch.nn.functional as F
from numpy import sqrt
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.utils import save_image, make_grid
import numpy as np
from utils import Constants
from .resnet_block import ResnetBlock
from .gmrf_vae import GMRF_VAE


# Constants
dataSize = torch.Size([1, 64, 64])

def actvn(x):
    out = torch.nn.functional.leaky_relu(x, 2e-1)
    return out




# Encoder network
class Enc(nn.Module):
    """ Generate latent parameters for SVHN image data. """

    def __init__(self,  latent_dim, diagonal_transf):
        super().__init__()
        self.diagonal_transf = diagonal_transf
        self.latent_dim = latent_dim
        self.enc = nn.Sequential(
            nn.Conv2d(1, 16, kernel_size=4, stride=2, padding=1),  # -> 16, 64, 64
            nn.ReLU(True),
            
            nn.Conv2d(16, 32, kernel_size=4, stride=2, padding=1), # -> 32, 32, 32
            nn.ReLU(True),
            
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1), # -> 64, 16, 16
            nn.ReLU(True),
            
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),# -> 128, 4, 4
            nn.ReLU(True),
                        
            # nn.Flatten()  # -> 64 * 8 * 8 = 32768
        )
        
        # Separate layers for mean and log variance of beta
        self.fc_mu_z = nn.Linear(128*4*4, latent_dim)
        self.lambda_diag_layer = nn.Linear(128*4*4, latent_dim)  # Diagonal elements
        self.cov_layer = nn.Linear(128*4*4, latent_dim)
        self.cov_embedding = None # going to be fed to the off diagonal model
        
    def forward(self, x):

        out_z = self.enc(x)
        # print('inside gmrf 64 out_z shape ', out_z.shape)
        out_z = out_z.view(out_z.size()[0], 128 * 4 * 4)
        self.cov_embedding = self.cov_layer(out_z) # going to be fed to the off diagonal model
        mu_z = self.fc_mu_z(out_z)
        
        # Diagonal should be positive
        
        raw_diag = self.lambda_diag_layer(out_z)
        
        
        if self.diagonal_transf == 'relu':
            lambda_diag = nn.ReLU()(raw_diag) + Constants.relu_shift
        
        elif self.diagonal_transf == 'softplus':
            lambda_diag = torch.nn.functional.softplus(raw_diag)+ Constants.relu_shift
                
        elif self.diagonal_transf == 'square':
            lambda_diag = torch.square(raw_diag)
            
        elif self.diagonal_transf == 'exp':
            lambda_diag = torch.exp(raw_diag)
            # lambda_diag = torch.exp((raw_diag +Constants. exp_shift)/Constants.exp_factor)
        elif self.diagonal_transf == 'sig':
            lambda_diag = nn.Sigmoid()(raw_diag)
        else:
            raise ValueError(f"Invalid value for diagonal_transf: {self.diagonal_transf}. Unknown transformation")


        # Constructing the full matrix using tril_indices method
        lambda_z = torch.zeros(out_z.size(0), self.latent_dim, self.latent_dim, device=out_z.device)
        lambda_z.diagonal(dim1=-2, dim2=-1).copy_(lambda_diag)  # Fill in the diagonal
       
        return mu_z, lambda_z
        # return torch.cat((self.fc_mu_w(out_w), self.fc_mu_z(out_z)), dim=-1), \
        #        torch.cat((F.softmax(lv_w, dim=-1) * lv_w.size(-1) + Constants.eta,
        #                   F.softmax(lv_z, dim=-1) * lv_z.size(-1) + Constants.eta), dim=-1)

# Decoder network
class Dec(nn.Module):
    """ Generate a SVHN image given a sample from the latent space. """

    def __init__(self, latent_dim):
        super().__init__()
        self.latent_dim = latent_dim
        # NOTE: I've set below variables according to Kieran's suggestions
        # ---- Decoder ----
        # First map from latent_dim -> flatten shape
        self.fc = nn.Linear(latent_dim, 128*4*4)

        # We'll reshape to (512, 8, 8) and apply transposed conv
        self.dec = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1), # -> 64,8,8
            nn.ReLU(True),
            
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1), # -> 32 16 16
            nn.ReLU(True),
            
            nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1),  # -> 16 32 32
            nn.ReLU(True),
            
            nn.ConvTranspose2d(16, 1, kernel_size=4, stride=2, padding=1),   # -> 1 64 64        
            
        )
        
        # self.conv_img = nn.Conv2d(nf, 1, 3, padding=1)
        
              
    def forward(self, u):
        # print('u shape ', u.shape)
        out = self.fc(u).view(u.size(0), 128,4,4)
        out = self.dec(out)
        # print('out shape ', out.shape)
        return out#, torch.tensor(0.75).to(u.device)  # mean, length scale


    
    
class GMRF_VAE_EPURE(GMRF_VAE):
    def __init__(self, params):
        super(GMRF_VAE_EPURE, self).__init__()
        self.enc = Enc(params.latent_dim, params.diagonal_transf)
        self.dec = Dec(params.latent_dim)
        self.latent_dim = params.latent_dim
        self.tmpdir = params.tmpdir
        
        
        self.modelName = 'gmrf_cnn_64'
        self.dataSize = dataSize
        # self.llik_scaling = 1.
        self.params = params
        
        
   