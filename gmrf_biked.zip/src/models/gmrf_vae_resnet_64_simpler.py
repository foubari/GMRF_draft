# PolyMNIST model specification
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from utils import Constants
from .gmrf_vae import GMRF_VAE



# Constants
dataSize = torch.Size([1, 64, 64])

def actvn(x):
    out = torch.nn.functional.leaky_relu(x, 2e-1)
    return out



class SimpleResnetBlock(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.learned_shortcut = (in_dim != out_dim)
        self.in_dim = in_dim
        self.out_dim = out_dim
        hidden_dim = min(in_dim, out_dim)

        self.conv1 = nn.Conv2d(in_dim, hidden_dim, 3, padding=1)
        self.conv2 = nn.Conv2d(hidden_dim, out_dim, 3, padding=1)
        
        if self.learned_shortcut:
            self.conv_sc = nn.Conv2d(in_dim, out_dim, 1, padding=0)

    def forward(self, x):
        # Shortcut
        if self.learned_shortcut:
            x_s = self.conv_sc(x)
        else:
            x_s = x

        # Residual
        dx = F.leaky_relu(self.conv1(x), 0.2)
        dx = self.conv2(dx)
        return x_s + 0.1 * dx
    
    
class Enc(nn.Module):
    def __init__(self, latent_dim=64, diagonal_transf='softplus'):
        super().__init__()
        # We'll define 3 downsampling stages: 64x64 -> 32x32 -> 16x16 -> 8x8
        # Start with 32 channels, then 64, then 128
        self.base_nf = 32
        self.diagonal_transf = diagonal_transf
        self.latent_dim = latent_dim
        
        # 1) Conv in: 1 -> 32, downsample
        self.down1 = nn.Sequential(
            nn.Conv2d(1, 32, 4, stride=2, padding=1),  # 64->32
            nn.LeakyReLU(0.2, inplace=True),
            SimpleResnetBlock(32, 32)
        )
        # 2) 32 -> 64, downsample
        self.down2 = nn.Sequential(
            nn.Conv2d(32, 64, 4, stride=2, padding=1), # 32->16
            nn.LeakyReLU(0.2, inplace=True),
            SimpleResnetBlock(64, 64)
        )
        # 3) 64 -> 128, downsample
        self.down3 = nn.Sequential(
            nn.Conv2d(64, 128, 4, stride=2, padding=1),# 16->8
            nn.LeakyReLU(0.2, inplace=True),
            SimpleResnetBlock(128, 128)
        )

        # At this point, feature map is [B, 128, 8, 8].
        self.flatten_dim = 128 * 8 * 8
        
        
        # Separate layers for mean and log variance of beta
        self.fc_mu_z = nn.Linear(self.flatten_dim, latent_dim)
        self.lambda_diag_layer = nn.Linear(self.flatten_dim, latent_dim) # Diagonal elements
        self.cov_layer = nn.Linear(self.flatten_dim, latent_dim)
        self.cov_embedding = None # going to be fed to the off diagonal model

    def forward(self, x):
        x = self.down1(x)  # B, 32, 32, 32
        x = self.down2(x)  # B, 64, 16, 16
        x = self.down3(x)  # B, 128, 8, 8
        x = x.view(x.size(0), -1)  # B, 128*8*8

        
        self.cov_embedding = self.cov_layer(x) 
        mu = self.fc_mu_z(x)
        # Diagonal should be positive
        raw_diag = self.lambda_diag_layer(x)
        
        
        if self.diagonal_transf == 'relu':
            lambda_diag = nn.ReLU()(raw_diag) + Constants.relu_shift
        
        elif self.diagonal_transf == 'softplus':
            lambda_diag = torch.nn.functional.softplus(raw_diag)+ Constants.relu_shift
                
        elif self.diagonal_transf == 'square':
            lambda_diag = torch.square(raw_diag)
            
        elif self.diagonal_transf == 'exp':
            lambda_diag = torch.exp(raw_diag)
            # lambda_diag = torch.exp((raw_diag +Constants. exp_shift)/Constants.exp_factor)
        elif self.diagonal_transf == 'sig':
            lambda_diag = nn.Sigmoid()(raw_diag)
        else:
            raise ValueError(f"Invalid value for diagonal_transf: {self.diagonal_transf}. Unknown transformation")


        # Constructing the full matrix using tril_indices method
        lambda_z = torch.zeros(mu.size(0), self.latent_dim, self.latent_dim, device=mu.device)
        lambda_z.diagonal(dim1=-2, dim2=-1).copy_(lambda_diag)  # Fill in the diagonal
       
        return mu, lambda_z
    
class Dec(nn.Module):
    def __init__(self, latent_dim=64):
        super().__init__()
        self.latent_dim = latent_dim

        # Mirror the encoder: 128->64->32->1 output
        self.fc = nn.Linear(latent_dim, 128 * 8 * 8)

        self.up1 = nn.Sequential(
            SimpleResnetBlock(128, 128),
            nn.ConvTranspose2d(128, 64, 4, stride=2, padding=1),  # 8->16
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.up2 = nn.Sequential(
            SimpleResnetBlock(64, 64),
            nn.ConvTranspose2d(64, 32, 4, stride=2, padding=1),   # 16->32
            nn.LeakyReLU(0.2, inplace=True)
        )
        self.up3 = nn.Sequential(
            SimpleResnetBlock(32, 32),
            nn.ConvTranspose2d(32, 1, 4, stride=2, padding=1),    # 32->64
            # If your data is in [0,1], you can do a final Sigmoid
            # or leave it as raw logits and apply e.g. BCE loss
        )

    def forward(self, z):
        x = self.fc(z).view(-1, 128, 8, 8)  # B,128,8,8
        x = self.up1(x)  # -> B,64,16,16
        x = self.up2(x)  # -> B,32,32,32
        x = self.up3(x)  # -> B,1,64,64
        return x


    
    
    
class GMRF_VAE_BIKED(GMRF_VAE):
    def __init__(self, params):
        super(GMRF_VAE_BIKED, self).__init__()
        self.enc = Enc(params.latent_dim, params.diagonal_transf)
        self.dec = Dec(params.latent_dim)
        self.latent_dim = params.latent_dim
        self.tmpdir = params.tmpdir
        
        
        self.modelName = 'gmrf_resnet'
        self.dataSize = dataSize
        # self.llik_scaling = 1.
        self.params = params
        
        
   