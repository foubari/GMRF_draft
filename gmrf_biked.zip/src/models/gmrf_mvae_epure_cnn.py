from .gmrf_mvae import GMRF_MVAE
from .gmrf_vae_cnn_64 import GMRF_VAE_EPURE
from .cov_model import OffDiagonalCov
from torchvision import transforms
from torchvision.utils import save_image
from dataset_epure import MultiComponentDataset
from torch.utils.data import DataLoader




class Epure_GMMVAE(GMRF_MVAE):
    def __init__(self, params):
        super(Epure_GMMVAE, self).__init__(params, OffDiagonalCov, GMRF_VAE_EPURE, GMRF_VAE_EPURE, GMRF_VAE_EPURE, GMRF_VAE_EPURE, GMRF_VAE_EPURE, GMRF_VAE_EPURE)
        self.modelName = 'gmrf_mvae_epure'
        for idx, vae in enumerate(self.modality_vaes):
            vae.modelName = 'component_'+str(idx)
            vae.llik_scaling = 1.0
        self.tmpdir = params.tmpdir
        
    def getDataLoaders(self, batch_size, shuffle=True, device='cuda', num_workers = 4, pin_memory = False):
        # image_size = 64
        transform = transforms.Compose([
            # transforms.Resize((image_size, image_size)),
            transforms.RandomVerticalFlip(p=1),
            transforms.ToTensor(),  # [0, 1]
            # transforms.Normalize([0.5], [0.5])  # Map [0,1] -> [-1,1] for 1 channel
        ])
        root_dir = '../data/rescaled_images_64/' #
        # root_dir = './data/components_64/components/'
        component_dirs = ['group_nc', 'group_km', 'bt', 'gi', 'fpu', 'tpc']  # List of components
        dataset = MultiComponentDataset(root_dir, component_dirs,transform)
        # Split the dataset into training and testing sets
        train_dataset, test_dataset = dataset.split_data(test_size=0.1, seed=42)
        kwargs = {'num_workers': num_workers, 'pin_memory': pin_memory} if device == 'cuda' else {}
        train = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)
        test = DataLoader(test_dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)
        return train, test
    
    
    def generate_for_calculating_unconditional_coherence(self, N):
        samples_list = super(Epure_GMMVAE, self).generate(N)
        return [samples.data.cpu() for samples in samples_list]

    def generate_for_fid(self, savedir, num_samples, tranche):
        N = num_samples
        samples_list = super(Epure_GMMVAE, self).generate(N)
        for i, samples in enumerate(samples_list):
            samples = samples.data.cpu()
            for image in range(samples.size(0)):
                save_image(samples[image, :, :, :], '{}/random/m{}/{}_{}.png'.format(savedir, i, tranche, image))

    def reconstruct_for_fid(self, data, savedir, i):
        recons_mat = super(Epure_GMMVAE, self).reconstruct_and_cross_reconstruct([d for d in data])
        for r, recons_list in enumerate(recons_mat):
            for o, recon in enumerate(recons_list):
                recon = recon.squeeze(0).cpu()
                for image in range(recon.size(0)):
                    save_image(recon[image, :, :, :],
                                '{}/m{}/m{}/{}_{}.png'.format(savedir, r,o, image, i))