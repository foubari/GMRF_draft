# Base GMRF_MVAE class definition
import torch
import torch.nn as nn
from torch.distributions import MultivariateNormal, Normal, Laplace
from utils import assemble_covariance_matrix_corrected, Constants




class GMRF_MVAE(nn.Module):
    def __init__(self, params, off_diag_cov,  *modality_vaes):
        super(GMRF_MVAE, self).__init__()
        print('iside latest model')
        # self.beta = nn.Parameter(torch.tensor(.001))
        
        self.diagonal_transf = params.diagonal_transf
        self.device = params.device
        # List of individual VAEs for each modality.
        self.modality_vaes = nn.ModuleList([vae(params).to(params.device) for vae in modality_vaes]) 
        
        # Initialize models for off-diagonal covariance calculation.
        # cov_input_dims = [self.modality_vaes[0].enc.nf0*self.modality_vaes[0].enc.s0**2,1024]
        cov_input_dims = [params.latent_dim for _ in range(len(self.modality_vaes))]
        encoded_dims = [params.latent_dim for _ in range(len(self.modality_vaes))]
        self.encoded_dims=encoded_dims
        self.off_diag_cov = off_diag_cov(input_dims=cov_input_dims ,encoded_dims=encoded_dims,
                                         hidden_dim =params.hidden_dim, n_layers=params.n_layers).to(self.device)  # Model to calculate off-diagonal elements for q(z|X)

        # Latent dimension assumed to be consistent across modalities.
        self.latent_dim = params.latent_dim

        
        # Total latent dimension across all modalities
        total_latent_dim = len(self.modality_vaes) * self.latent_dim
        
#         # Initialize parameters for mu_p and L_sigma_p
        self.mu_p = nn.Parameter(torch.ones(total_latent_dim).to(self.device)* 1e-4)
        
#         # Initialize diagonal elements with small positive values and off-diagonal elements with values from a Gaussian
        self.reduced_diag = params.reduced_diag
        
        self.diag_p = nn.Parameter(torch.ones(total_latent_dim).to(self.device))#*1e-2)# #so far we trained with torch.sone and 1e-2
            
#         # laplace_distribution = Laplace(loc=torch.tensor(0.0), scale=torch.tensor(0.25))
#         # off_diag_values = laplace_distribution.sample((total_latent_dim * (total_latent_dim - 1) // 2,))
#         # tril_indices = torch.tril_indices(row=total_latent_dim, col=total_latent_dim, offset=-1)
#         # self.off_diag_p = nn.Parameter(off_diag_values.to(self.device))

        tril_indices = torch.tril_indices(row=total_latent_dim, col=total_latent_dim, offset=-1)
        self.off_diag_scale = .1
        print('off_diag_scale ', self.off_diag_scale)
        self.off_diag_p = nn.Parameter((torch.ones(total_latent_dim*(total_latent_dim-1)//2)*self.off_diag_scale).to(self.device))     
        # self.cov_p = nn.Parameter((torch.ones(total_latent_dim*(total_latent_dim+1)//2)*self.off_diag_scale).to(self.device))
        # self.alpha_vector = nn.Parameter(torch.randn(total_latent_dim).to(self.device))

        self.recons = None
    
    def sample_from_pz(self, n_samples):
        """
        Sample n elements from the distribution p(z).

        :param n_samples: Number of samples required.
        :return: Tensor of samples from p(z).
        """
        distribution = self.get_prior()
        samples = distribution.sample((n_samples,))
        return samples
    
    def get_sigma_p(self):
        if  self.reduced_diag:
            diag_elements = self.diag_p
        else:
            # Diagonal should be positive
            if self.diagonal_transf == 'relu':
                diag_elements =  nn.ReLU()(self.diag_p)+ Constants.relu_shift
                # lambda_diag = nn.ReLU()(self.lambda_diag_layer(out_z)) 
            elif self.diagonal_transf == 'softplus':
                diag_elements = torch.nn.functional.softplus(self.diag_p)+ 1e-6#Constants.relu_shift
            elif self.diagonal_transf == 'square':
                diag_elements = torch.square(self.diag_p)
            elif self.diagonal_transf == 'exp':
                diag_elements = torch.exp(self.diag_p)
                # diag_elements = torch.exp((self.diag_p+Constants. exp_shift)/Constants.exp_factor)
                # lambda_diag = torch.exp((self.lambda_diag_layer(out_z) +Constants. exp_shift)/Constants.exp_factor)
            elif self.diagonal_transf == 'sig':
                diag_elements =  nn.Sigmoid()(self.diag_p)
            
            else:
                raise ValueError(f"Invalid value for diagonal_transf: {self.diagonal_transf}. Unknown transformation")
        

        lower_matrix = torch.zeros(self.mu_p.shape[0], self.mu_p.shape[0], device=self.mu_p.device)
        tril_indices = torch.tril_indices(row=self.mu_p.shape[0], col=self.mu_p.shape[0], offset=-1)
        lower_matrix[tril_indices[0], tril_indices[1]] = self.off_diag_p
        

        symmetric_matrix = lower_matrix +lower_matrix.T
        absolute_sum = symmetric_matrix.abs().sum(0)
        dominant_diagonal = absolute_sum+diag_elements
        # symmetric_matrix.diagonal(dim1=-2, dim2=-1).copy_(dominant_diagonal)
        # Step 5:  Diagonal Assignment
        sigma_p = symmetric_matrix.clone()  # Copy to avoid modifying original tensor
        sigma_p.diagonal(dim1=-2, dim2=-1).copy_(diag_elements)
        # sigma_p.fill_diagonal_(dominant_diagonal)  # Properly update diagonal

        return sigma_p
    
    def get_prior(self):
        mu = self.mu_p
        Sigma_p = self.get_sigma_p()
        return MultivariateNormal(mu, covariance_matrix=Sigma_p)
    
    def forward(self, x, K=1):
        # 1. Encoding Phase

        

        # List to store means and Sigmas for each modality. And the embedings to be fed the the off-diag model
        mus, Sigmas, off_diag_embed = [], [], []

        # Encode each input modality with its respective VAE encoder.
        for x_, vae in zip(x, self.modality_vaes):
            mu, Sigma = vae.enc(x_)
            mus.append(mu)
            Sigmas.append(Sigma)
            # print('inside gmrf mvae corrected')
            # print('mu shape ',mu.shape)
            # print('sigma shape ',Sigma.shape)
            cov_embedding = vae.enc.cov_embedding
            # print('cov_embedding shape ', cov_embedding.shape)
            # print('inside gmrf_mvae class cov_embedding.shape', cov_embedding.shape)
            off_diag_embed.append(cov_embedding)
            
        # Calculate the off-diagonal elements for q(z|X)
        off_diag_z_x = self.off_diag_cov(*off_diag_embed)
        # Concatenate means from all modalities.
        mu_z_x = torch.cat(mus, dim=1)

        # Assemble the full covariance matrix for q(z|X).
        
        # L_z_x = assemble_covariance_matrix(mus, Ls, off_diag_z_x, [self.latent_dim for _ in range(len(self.modality_vaes))] )
        
        Sigma_x = assemble_covariance_matrix_corrected(mus, Sigmas, off_diag_z_x, self.encoded_dims)
        # print('sigma_x shape ', Sigma_x.shape)
        mu_z_x = mu_z_x.to(self.device)
        Sigma_x = Sigma_x.to(self.device)
        
        self.Sigmaq = Sigma_x
        self.muq = mu_z_x
        # Define the multivariate normal distribution for q(z|X)
        # print('here')
        self.qz_x = MultivariateNormal(mu_z_x, covariance_matrix =  Sigma_x)
        # print('there')

        # Sample a latent vector using the reparameterization trick.
        self.z_x = self.qz_x.rsample().to(self.device) #torch.Size([K])
        # print('self.z_x shape ', self.z_x.shape)

        # 2. Decoding Phase

        # Split the latent vector for each modality.
        z_splits = torch.split(self.z_x, self.latent_dim, dim=1)# dim=2 when size[K]

        # Reset the means list for decoding.
        mus = []

        # Decode each latent vector split with its respective VAE decoder.
        for z, vae in zip(z_splits, self.modality_vaes):
            # print('z shape ',z.shape)
            mu = vae.dec(z)
            # print('recon shape ', mu.shape)
            mus.append(mu)
            # vae.px_z = Normal(mu,vae.px_z_cov)
            # print('sample from px_z ',vae.px_z.sample().shape)
        self.recons = mus
    
    def decode(self, z):
        # Split the latent vector for each modality.
        z_splits = torch.split(z, self.latent_dim, dim=1)# dim=2 when size[K]

        # Reset the means lists for decoding.
        mus = []

        # Decode each latent vector split with its respective VAE decoder.
        for z, vae in zip(z_splits, self.modality_vaes):
            # print('z shape ',z.shape)
            mu = vae.dec(z)
            # print('mu shape ', mu.shape)
            mus.append(mu)
            # vae.px_z = Normal(mu,vae.px_z_cov)
            # print('sample from px_z ',vae.px_z.sample().shape)
        self.recons = mus
        return mus

    def generate(self, num_samples=1):#generate_unconditional
        """
        Generate new samples from the model.

        :param num_samples: Number of samples to generate.
        :return: Generated samples.
        """
        # Sample from p(z)

        z = self.sample_from_pz(num_samples)

        # Split the latent vector for each modality.
        z_splits = torch.split(z, self.latent_dim, dim=1)

        # Decode the sampled z.
        # generated_samples = []
        mus = []
        for z_split, vae in zip(z_splits, self.modality_vaes):
            mus.append(vae.dec(z_split))
        return mus
    
    def conditional_generate(self, cond, idx_i, idx_cond, n_sample=1):
        """
        Compute conditional mean and Cholesky factor for generating X_i given X_j in PyTorch for batch inputs.

        Parameters:
        - cond: Observed latent variable z for the conditioning modality with shape [batch_size, latent_dim].
        - idx_i: Index of target modality X_i.
        - idx_cond: Index of conditioning modality X_j.
        - n_sample: Number of samples to generate.

        Returns:
        - sample: Generated samples for X_i given X_j with shape [batch_size, n_sample, latent_dim].
        """
        
            
        # Decoding condition for each item in the batch
        m, l = self.modality_vaes[idx_cond].enc(cond)
        dist = MultivariateNormal(m, scale_tril=l)
        cond_z = dist.sample([n_sample])  # Sample with shape [n_sample, batch_size, latent_dim]
        
        if idx_i==idx_cond:
            return self.modality_vaes[idx_cond].dec(cond_z)

        # Adjust for batch processing: repeat mu_p and get_cholesky for each batch item
        batch_size = cond.shape[0]
        mu_p_batch = self.mu_p.repeat(batch_size, 1)  # Repeat mu_p for each item in the batch
        Sigma = self.get_sigma_p().repeat(batch_size, 1, 1)

        # Indices for slicing
        start_i, end_i = idx_i * self.latent_dim, (idx_i + 1) * self.latent_dim
        start_j, end_j = idx_cond * self.latent_dim, (idx_cond + 1) * self.latent_dim

        # Extract relevant blocks for each item in the batch
        mu_i = mu_p_batch[:, start_i:end_i]
        mu_j = mu_p_batch[:, start_j:end_j]

        # Compute covariance matrices for the batch
        Sigma_ii = Sigma[:, start_i:end_i, start_i:end_i]
        Sigma_jj = Sigma[:, start_j:end_j, start_j:end_j]
        Sigma_c = Sigma[:, start_i:end_i, start_j:end_j]

        # Invert Sigma_jj for each item in the batch
        Sigma_jj_inv = torch.inverse(Sigma_jj)

        # Compute conditional means and covariance matrices for the batch
        mu_cond = mu_i + torch.matmul(torch.matmul(Sigma_c, Sigma_jj_inv), (cond_z - mu_j).unsqueeze(-1)).squeeze(-1).squeeze(0)
        Sigma_cond = Sigma_ii - torch.matmul(torch.matmul(Sigma_c, Sigma_jj_inv), Sigma_c.transpose(-2, -1))

        # Generate samples for each item in the batch
        samples = []
        for i in range(batch_size):
            cond_dist = MultivariateNormal(mu_cond[i], covariance_matrix=Sigma_cond[i])
            sample = cond_dist.sample((n_sample,))
            samples.append(sample)
        # samples = []
        # print('modify cond gen to sampling')
        # for i in range(batch_size):
        #     samples.append(mu_cond[i].unsqueeze(0).expand(n_sample, -1))

        samples = torch.cat(samples, dim=0)  # Shape [batch_size, n_sample, latent_dim]
        conditional_generation = self.modality_vaes[idx_i].dec(samples)
        return conditional_generation
    

    def self_and_cross_modal_generation(self, data):
        
        recons = [[None for _ in range(len(self.modality_vaes))] for _ in range(len(self.modality_vaes))]
        self.eval()
        
        with torch.no_grad():
            for idx_cond in range(len(self.modality_vaes)):
                for idx_i,vae in enumerate(self.modality_vaes):
                    recons[idx_cond][idx_i] = self.conditional_generate(data[idx_cond], idx_i, idx_cond, n_sample=1)
                # ------------------------------------------------
                # cross-modal matrix of reconstructions
        return recons
    
    
    def getDataLoaders(batch_size, shuffle=True, device="cuda"):
        # handle merging individual datasets appropriately in sub-class
        raise NotImplementedError