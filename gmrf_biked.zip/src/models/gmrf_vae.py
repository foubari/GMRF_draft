# Base VAE class definition

import torch
import torch.nn as nn

class GMRF_VAE(nn.Module):
    def __init__(self,):
        super(GMRF_VAE, self).__init__()        
     # likelyhood parameters
        self.px_z_mean = None
        self.px_z_cov =  None #nn.Parameter(torch.ones(1))
        self.px_z = None