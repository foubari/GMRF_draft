# PolyMNIST model specification
import torch
import torch.distributions as dist
import torch.nn as nn
import torch.nn.functional as F
from numpy import sqrt
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision.utils import save_image, make_grid
import numpy as np
from utils import Constants
from .resnet_block import ResnetBlock
from .gmrf_vae import GMRF_VAE


# Constants
dataSize = torch.Size([1, 64, 64])

def actvn(x):
    out = torch.nn.functional.leaky_relu(x, 2e-1)
    return out

# Constants
dataSize = torch.Size([1, 256, 256])  # Updated

def actvn(x):
    return torch.nn.functional.leaky_relu(x, 2e-1)

import torch
import torch.nn as nn
import torch.nn.functional as F

# -------------------------------------------------------------
# 1) Small Encoder
# -------------------------------------------------------------
class Enc(nn.Module):
    def __init__(self, latent_dim=64, in_channels=1):
        """
        Args:
            latent_dim (int): dimension of the latent space
            in_channels (int): number of input channels (1 for grayscale)
        """
        super().__init__()
        # Start with fewer channels, e.g. 16, then double
        # 256 -> 128 -> 64 -> 32 -> 16 (spatial dims)
        # Channels: 16 -> 32 -> 64 -> 128
        # block_out = 128 at the final resolution 16×16

        self.latent_dim = latent_dim

        # Block 1: 1 -> 16 channels, stride=2 (reduce spatial dims from 256->128)
        self.enc_block1 = nn.Sequential(
            nn.Conv2d(in_channels, 16, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True)
        )
        # Block 2: 16 -> 32 channels, 128->64
        self.enc_block2 = nn.Sequential(
            nn.Conv2d(16, 32, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True)
        )
        # Block 3: 32 -> 64 channels, 64->32
        self.enc_block3 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        # Block 4: 64 -> 128 channels, 32->16
        self.enc_block4 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True)
        )

        # Final spatial resolution is 16×16, with 128 channels
        # Flatten and map to mean & logvar (or diag precision, etc.)
        self.flatten_dim = 128 * 16 * 16

        self.fc_mu = nn.Linear(self.flatten_dim, latent_dim)
        # For diagonal covariance, you can store log_var, or use another transform
        # We'll do log_var for simplicity
        self.fc_logvar = nn.Linear(self.flatten_dim, latent_dim)

    def forward(self, x):
        # Downsample steps
        x = self.enc_block1(x)  # B, 16, 128, 128
        x = self.enc_block2(x)  # B, 32, 64, 64
        x = self.enc_block3(x)  # B, 64, 32, 32
        x = self.enc_block4(x)  # B, 128, 16, 16

        # Flatten
        x = x.view(x.size(0), -1)  # B, 128*16*16

        # Mean & log-variance
        mu = self.fc_mu(x)        # B, latent_dim
        logvar = self.fc_logvar(x)# B, latent_dim

        return mu, logvar

# -------------------------------------------------------------
# 2) Small Decoder
# -------------------------------------------------------------
class Dec(nn.Module):
    def __init__(self, latent_dim=64, out_channels=1):
        super().__init__()
        # Mirror the encoder's channel progression in reverse
        self.latent_dim = latent_dim

        # Map from latent_dim back to flattened feature map
        self.fc = nn.Linear(latent_dim, 128 * 16 * 16)

        # 16×16, 128 -> upsample to 32×32, 64
        self.dec_block1 = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True)
        )
        # 32×32, 64 -> 64×64, 32
        self.dec_block2 = nn.Sequential(
            nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True)
        )
        # 64×64, 32 -> 128×128, 16
        self.dec_block3 = nn.Sequential(
            nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1),
            nn.BatchNorm2d(16),
            nn.ReLU(inplace=True)
        )
        # 128×128, 16 -> 256×256, out_channels
        self.dec_block4 = nn.Sequential(
            nn.ConvTranspose2d(16, out_channels, kernel_size=4, stride=2, padding=1),
            # no batchnorm or ReLU for the final layer by default
            # you might want a sigmoid or tanh if your data is normalized 0-1 or -1..1
        )

    def forward(self, z):
        # Fully connected to get back to shape [B, 128, 16, 16]
        x = self.fc(z).view(z.size(0), 128, 16, 16)

        # Upsample steps
        x = self.dec_block1(x)  # -> B,64, 32, 32
        x = self.dec_block2(x)  # -> B,32, 64, 64
        x = self.dec_block3(x)  # -> B,16,128,128
        x = self.dec_block4(x)  # -> B,1, 256,256

        return x

# -------------------------------------------------------------
# 3


    
    
class GMRF_VAE_CT_MRI(GMRF_VAE):
    def __init__(self, params):
        super(GMRF_VAE_EPURE, self).__init__()
        self.enc = Enc(params.latent_dim, params.diagonal_transf)
        self.dec = Dec(params.latent_dim)
        self.latent_dim = params.latent_dim
        self.tmpdir = params.tmpdir
        
        
        self.modelName = 'gmrf_cnn'
        self.dataSize = dataSize
        # self.llik_scaling = 1.
        self.params = params
        
        
   