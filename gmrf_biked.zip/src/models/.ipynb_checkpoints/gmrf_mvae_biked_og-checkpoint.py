from .gmrf_mvae import GMRF_MVAE
from .gmrf_vae_resnet_64 import GMRF_VAE_BIKED
from .cov_model import OffDiagonalCov
from torchvision import transforms
from torchvision.utils import save_image
from dataset_Biked import BIKED_Dataset
from torch.utils.data import DataLoader


component_names = ['crank', 'frame', 'handle', 'saddle', 'wheel']
data_path = '../biked_data/BIKED Dataset/BIKED Dataset/train_test_images_res64x64'

class Biked_GMMVAE(GMRF_MVAE):
    def __init__(self, params):
        super(Biked_GMMVAE, self).__init__(params, OffDiagonalCov, GMRF_VAE_BIKED, GMRF_VAE_BIKED, GMRF_VAE_BIKED, GMRF_VAE_BIKED, GMRF_VAE_BIKED)
        self.modelName = 'gmrf_mvae_biked'
        for vae, component  in zip(self.modality_vaes, component_names):
            vae.modelName = 'component_'+component
            vae.llik_scaling = 1.0
        self.tmpdir = params.tmpdir
        
    def getDataLoaders(self, batch_size, shuffle=True, device='cuda', num_workers = 4, pin_memory = False, resolution=64):
        # Define the transformations
        transformations = transforms.Compose([
            # transforms.Resize((resolution, resolution)),   
            transforms.Grayscale(num_output_channels=1),  # Convert to grayscale (1 channel)
            transforms.ToTensor(),
            # transforms.Lambda(lambda x: 1 - x)  # Inverts the pixel values
        ])

        # Pass the transformations to the dataset
        train_dataset = BIKED_Dataset(data_path, split="train", component_dirs=component_names, transform=transformations)
        test_dataset = BIKED_Dataset(data_path, split="test", component_dirs=component_names, transform=transformations)

        
        kwargs = {'num_workers': num_workers, 'pin_memory': pin_memory} if device == 'cuda' else {}
        train = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)
        test = DataLoader(test_dataset, batch_size=batch_size, shuffle=shuffle, **kwargs)
        return train, test
    
    
    def generate_for_calculating_unconditional_coherence(self, N):
        samples_list = super(Biked_GMMVAE, self).generate(N)
        return [samples.data.cpu() for samples in samples_list]

    def generate_for_fid(self, savedir, num_samples, tranche):
        N = num_samples
        samples_list = super(Biked_GMMVAE, self).generate(N)
        for samples, component in zip(samples_list,component_names):
            samples = samples.data.cpu()
            for image in range(samples.size(0)):
                save_image(samples[image, :, :, :], '{}/random/{}/{}_{}.png'.format(savedir, component, tranche, image))

    def reconstruct_for_fid(self, data, savedir, i):
        recons_mat = super(Biked_GMMVAE, self).self_and_cross_modal_generation([d for d in data])
        for recons_list, component_i in zip(recons_mat, component_names):
            for recon, component_j in zip(recons_list, component_names):
                recon = recon.squeeze(0).cpu()
                for image in range(recon.size(0)):
                    save_image(recon[image, :, :, :],
                                '{}/{}/{}/{}_{}.png'.format(savedir, component_i,component_j, image, i))