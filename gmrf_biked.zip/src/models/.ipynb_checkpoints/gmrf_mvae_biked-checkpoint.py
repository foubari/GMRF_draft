from .gmrf_mvae import GMRF_MVAE
from .gmrf_vae_resnet_64 import GMRF_VAE_BIKED
from .cov_model import OffDiagonalCov
from torchvision import transforms
from torchvision.utils import save_image
from dataset_Biked import BIKED_Dataset
from torch.utils.data import DataLoader
from datasets_PolyMNIST import PolyMNISTDataset


component_names = ['m0', 'm1', 'm2', 'm3', 'm4']
data_path = '/NAS/USERS/e020199/BOMRGD/phd_fouad/mrf_mvae_project/data'

class Biked_GMMVAE(GMRF_MVAE):
    def __init__(self, params):
        super(Biked_GMMVAE, self).__init__(params, OffDiagonalCov, GMRF_VAE_BIKED, GMRF_VAE_BIKED, GMRF_VAE_BIKED, GMRF_VAE_BIKED, GMRF_VAE_BIKED)
        self.modelName = 'gmrf_mvae_biked'
        for vae, component  in zip(self.modality_vaes, component_names):
            vae.modelName = 'component_'+component
            vae.llik_scaling = 1.0
        self.tmpdir = params.tmpdir
        
    def getDataLoaders(self, batch_size, shuffle=True, device='cuda',num_workers=4, pin_memory=True):
        tx = transforms.ToTensor()
        unim_train_datapaths = [data_path+"/PolyMNIST/train/" + "m" + str(i) for i in [0, 1, 2, 3, 4]]
        unim_test_datapaths = [data_path+"/PolyMNIST/test/" + "m" + str(i) for i in [0, 1, 2, 3, 4]]
        dataset_PolyMNIST_train = PolyMNISTDataset(unim_train_datapaths, transform=tx)
        dataset_PolyMNIST_test = PolyMNISTDataset(unim_test_datapaths, transform=tx)
        kwargs = {'num_workers': num_workers, 'pin_memory': pin_memory} if device == device else {}
        train = DataLoader(dataset_PolyMNIST_train, batch_size=batch_size, shuffle=shuffle, **kwargs)
        test = DataLoader(dataset_PolyMNIST_test, batch_size=batch_size, shuffle=False, **kwargs)
        return train, test
    
    
    def generate_for_calculating_unconditional_coherence(self, N):
        samples_list = super(Biked_GMMVAE, self).generate(N)
        return [samples.data.cpu() for samples in samples_list]

    def generate_for_fid(self, savedir, num_samples, tranche):
        N = num_samples
        samples_list = super(Biked_GMMVAE, self).generate(N)
        for samples, component in zip(samples_list,component_names):
            samples = samples.data.cpu()
            for image in range(samples.size(0)):
                save_image(samples[image, :, :, :], '{}/random/{}/{}_{}.png'.format(savedir, component, tranche, image))

    def reconstruct_for_fid(self, data, savedir, i):
        recons_mat = super(Biked_GMMVAE, self).self_and_cross_modal_generation([d for d in data])
        for recons_list, component_i in zip(recons_mat, component_names):
            for recon, component_j in zip(recons_list, component_names):
                recon = recon.squeeze(0).cpu()
                for image in range(recon.size(0)):
                    save_image(recon[image, :, :, :],
                                '{}/{}/{}/{}_{}.png'.format(savedir, component_i,component_j, image, i))